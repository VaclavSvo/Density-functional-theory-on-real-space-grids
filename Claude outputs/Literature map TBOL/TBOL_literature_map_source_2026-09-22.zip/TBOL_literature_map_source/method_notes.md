# Method notes (kept from the start; the "How this map was made" box is written from this file)

## 2026-09-21 — phase 1

- Project: "DFT solver baseline" (claude.ai). Docs skimmed for the problem statement:
  `extra/thesis_topics/moire_thesis_options.md` (2026-09-16, updated 09-19),
  `extra/thesis_topics/option_B_pdf/optionB_proposal_v2.tex` (2026-09-18),
  `extra/thesis_topics/tbol_research_dossier.md` (2026-09-18/19),
  `extra/thesis_topics/optical_lattice_condensate_proposal.md` (2026-09-17/19),
  `extra/thesis_topics/physics_topics_and_research_plans.md` (2026-09-16/19),
  `extra/ml_xc_literature_map/README.md` (earlier map, different topic; style precedent only).
- Problem statement agreed with the user; answers in `work/questions.md`.
- Docs on other topics (solver plan, gates, decision log, ML-XC map) are out of scope and were not mined
  for sources.

## Phase 2 — reading the docs (see sources_inventory.md, facts_ledger.md)

- 2026-09-21. Read in full with project_read: tbol_research_dossier.md (2026-09-18, upd. 09-19; ~70 named sources + ~65 URLs in §7, of which 28 arXiv IDs carry no name); moire_thesis_options.md (09-16, upd. 09-19; ~40 physics sources in §2/§10 plus ~20 supervisor/platform items); optical_lattice_condensate_proposal.md (09-17, v2 notes 09-18/19; 35 numbered refs in §14 plus ~12 in the text); optionB_proposal_v2.tex (09-18; 20 refs); physics_topics_and_research_plans.md (09-16, upd. 09-19; §3 and the TBOL list of §8 mined: ~12 sources, all already in the other docs); grid.csv (104 rows × 47 columns); tbol_bands.py (skimmed: two-component plane-wave model, E_cut = 60, D₄-reduced k-mesh, Mathieu J and asymptotic "Zwerger" J).
- Result: 103 distinct named in-scope sources (4 `_nd` rows = results named without any reference: Leggett, Taylor–Zaremba, Zwerger, Nelson–Kosterlitz; 13 `anon` rows = first author not given) + 28 unattributed arXiv IDs from dossier §7, kept as separate rows for phase 3 to match. The true count is 103–131.
- Two attributions are inferred and marked as such: arXiv:1912.12736 → Salamon et al. (by elimination in the §7 "Proposals" list); DOI 10.1038/s41566-020-0679-9 → Fu et al. Nat. Photon. (by journal prefix). arXiv:2410.21371 is attributed by the dossier to "Johnstone et al."; that it is the PRA 111, 043305 companion is my inference.
- Out of scope, listed at the end of the inventory and not counted: supervisor, WPI, MMM, u:cris, u:find and ResearchGate pages; the supervisors' own maths and numerics papers; the UChicago news release; topic A (molecular/dipolar fluids, ~12), TDDFT (3), 1-D shock waves (3), false vacuum beyond Zenesini (2), magnonics beyond Mellado's review (4), AI-rules pages (2).
- Ledger: 238 lines (179 unchecked, 43 computed, 16 excluded). Computed lines were checked against grid.csv by hand. All 15 m = 8 rows of the dossier §4 table match grid.csv (columns W1_over_W1_fold0, gap12_indirect, mass_ratio_Gamma, trg_Gamma_over_LM2, Omega_I_over_LM2, nG_PR, nG_cg_AA_over_AB). gates.txt, effective_E1.csv, ecut_table.csv and J_table.csv are not in the Project, so the lines resting on them could not be re-read.
- Inconsistencies noticed:
  - Naming: TBOL is "Option B" in the proposal and v2.tex, "topic B" in physics_topics and "option A" in moire_thesis_options. The title also varies: "moiré pocket transition" (v2 subtitle) vs "crossover" (dossier).
  - Julku: the dossier cites PRL 127, 170404 and PRB 104, 144507 (+ erratum 2023) separately; proposal §14 [5] merges them into one entry, and v2.tex cites only the PRL.
  - Paul, Recher, Santos: "PRA 2025" in every doc, with no volume or pages. Wan–Gao–Shi: "PRL 2026", no volume. Møller: "PRR", no volume.
  - Journal name: "SciPost Codebases 9" (dossier) vs "SciPost Phys. Codebases 9" (proposal).
  - Meng numbers: E_r = h × 3.67 kHz (Meng) vs agent D's 3.678 kHz; Ω_R cap "≈ 1 E_r" vs "≤ 1.1 E_r" (the ED anchor); Rabi frequency 0.24 vs 0.243 E_r; temperature "not measured" (dossier §0) vs "not stated" (dossier §1); path III at "8 or 14" vs "8–14" E_r.
  - The Johnstone J range is written 10⁻¹¹–10⁻³ as J_max in §2.2 and 10⁻³–10⁻¹¹ as J_M in §5.3.
  - The AA/AB density ratio in the collapsed regime is ≥ 10⁵ (§4 interp. 2), 10⁵–10¹⁰ (§0), 10³–10¹⁰ (C3) and ≥ 10³ (proposal UPDATE). grid.csv gives coarse-grained 10³–10⁶ and raw 10⁵–10¹².
  - The crossover window is Ω/J ≈ 3–30 (§0, §4), 5–25 (C4, options, proposal), 1–30 (§5.1) and 10–30 (v2.tex).
  - "Weak m-dependence for m ≥ 6" / "W₁ ≥ 0.93 W₁(0) at V₀ = 4, Ω ≤ 1 E_R" holds at m = 8 but not at m = 12. The grid gives 0.59 there, and the experiment is at m = 22.
  - The folded-band formula 4J(1 − cos π/L) is only approximate against grid.csv. The "Ω/J ≈ 16–40" upper end is J(12 E_R), not 14 E_R.
  - The v2.tex Fig. 1c caption says the PR falls "two to three orders of magnitude" over Ω/J 10–30. grid.csv gives a factor of 24.

## Phase 3 — searches run

- 2026-09-21. Three research agents, WebSearch/WebFetch only, rules in work/research/COMMON_RULES.md; every call logged in **work/search_log.md**.
  R1 (TBOL bosons, the 28 unattributed dossier IDs, flat-band bosons, superfluid fraction, related platforms): 45 calls.
  R2 (electronic moiré context, flat-band superconductivity, industry, programmes, groups): 44 calls.
  R3 (methods, codes, compute, ML): 45 calls + a follow-up round of 18.
- Merge (phase 3 → 4): 52 new inventory rows (158 in scope), 107 new ledger lines F239–F345 (`to check`), 25 of 28 IDs resolved (x0905.3384, x0710.2703, x0901.0420 not reached), 8 anon keys renamed.
- New since the docs (most important):
  1. Rabec et al. is PRL 136, 133401 (2026): triangular lattice, f_s^(yy) = 0.82(2) at V₀ ≃ 2.4 gρ₀, two methods agree with GPE and Leggett bounds.
  2. Song et al. (Schneider group, arXiv Sep 2026): quenches across the Bose-glass transition in an optical quasicrystal.
  3. Walkling–Štrkalj–Ünal now published (PRR 8, 023356, 2026); Guimaraes–Sanchez-Palencia is now PRA 114, 023312 (2026); Wan–Gao–Shi PRL DOI found.
  4. Pizzino et al. (Dec 2025): Leggett's bound is reliable for strongly interacting bosons at the 2D–1D crossover.
  5. Corrections: orso2024 is a Fermi-gas paper; Underwood & Blakie is a spin-1 SPGPE (A. P. C. Underwood, PRA 112, 023315); arXiv:2404.18594 is Nagao & Yunoki, not Denis & Carleo (2404.07869); Schaffer et al. is micromagnetics.
  6. Confirmed numbers: Lühmann 0.0596(4) vs QMC 0.0597; Chen et al. 0.31 ± 0.03 vs KZ 3/4 (3-D lattice); Prokof'ev ξ = 380 ± 3; Dziarmaga–Mazur D = 11–14 (NTU cost ∝ D⁸); Underwood 2.5×10⁵ samples, 512² grid.
  7. The tWSe₂ pair is Xia et al. / Guo et al., Nature 637 (print year 2025); the non-Abelian tMoTe₂ FCI paper is theory, not an experiment.
  8. The TBG stiffness measurement (Tanaka 2025) has a companion (Banerjee et al., Nature 2025); abstract gives no numeric enhancement factor.
  9. 2026 context: Kavli Prize in Nanoscience for twistronics (reported by ACerS, to confirm); NSF QLCI round of 25 Aug 2026; quantA (Austria, up to €70 M); PASQuanS2.
  10. Codes: worm QMC GPL-3.0, no releases; ALPSCore v2.3.3 (May 2026); NetKet 3.22.4 (Aug 2026); XMDS2 news stops at 2014; GPUE first author is Schloss.
- Not found: no second TBOL experiment (Meng et al. 2023 is still the only one in the listings); no a₁₁/a₂₂/a₁₂ set for the |1,1⟩/|2,0⟩ pair (Egorov's values are for |1,−1⟩/|2,+1⟩); no released TBOL data (Meng et al.: "available … upon reasonable request", no code statement); no substantive moiré/twistronics commercialisation (no start-up, product or funded industrial programme); no ERC grant on quantum-gas superfluidity (one twistronics ERC, QTWIST); no CPU-hour figures for the worm code or Johnstone et al.; no GPU GPE timings; not confirmed: Braun 0.3–0.6, Mennemann 20 nK, Blakie J. Phys. B volume, Krämer et al. EPJD 27, 247.
- Routes: arxiv.org/abs sometimes returned the abstract without title/authors (≈ 10 times across agents); ar5iv.labs.arxiv.org worked every time (title + authors + body); journals.aps.org 403 (not called); nature.com worked but returned 429 once (s41586-025-08954-8, not retried); OpenAlex/Crossref 429 (not called); PubMed reCAPTCHA/empty; ADS robots-disallowed; scipost.org 403 (Anubis).

## Phase 4 — checking

- 2026-09-21. 10 rounds: batches 1–9 (round 1) plus one second pass (batch 10) for retries, unreached sources and open items. Checkpoints: work/verify/batch_1.md … batch_9.md, batch_10_secondpass.md; rules in verify/CHECKER_PROMPT.md.
- Agents: 4 checker agents, WebSearch/WebFetch only, each round capped at 9 min and 20 web calls (sleep 12 s between arXiv/ar5iv fetches); 196 web calls in total (batch 5: 19, batch 9: 19, batch 10: 18, the other seven 20 each).
- Routes that worked: ar5iv.labs.arxiv.org/html/ID (title, authors, body text; the main route); arxiv.org/abs and arxiv.org/html/ID…v1 (journal-ref lines; the abstract page sometimes without title/authors); arxiv.org/pdf (second pass); nature.com article pages (Nature family); quantum-journal.org, joss.theoj.org, sciencedirect abstract pages, IDEAS/RePEc records, GitHub, PyPI, Zenodo, institutional pages; WebSearch listings (bibliographic data only).
- Blocked or refused: journals.aps.org 403, api.openalex.org and api.crossref.org 429 (never called); SciPost 403, PubMed, ADS (never called); arxiv.org 429 twice (an author listing, one html page); link.springer.com 429 once. Both retries were cleared in round 10.
- Rule applied when merging: a line or source confirmed only in part, or only on a search listing, is `partly verified`; "verified"/"corrected" need a primary record.
- Sources (157 after 2 merges and 1 split): 37 verified, 16 corrected, 101 partly verified, 1 not verifiable (lukin2023), 0 retry, 2 to check (nagao2021, bradley2014spgpe, never reached).
- Ledger (345 lines): 140 verified, 29 corrected, 82 partly verified, 0 not verifiable, 30 unchecked, 5 to check, 43 computed, 16 excluded.
- refs.bib: 157 entries, parses cleanly (bibtexparser 2.0.1); unsrtnat dry run gives 157 \bibitem and 15 BibTeX warnings (6 empty author, 9 empty year on undated web pages), no LaTeX errors.
- Details: verify/progress.md (per-source status, rounds, notes), verify/renames.md, corrections_list.md (README seed).
