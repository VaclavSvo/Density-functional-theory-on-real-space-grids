#!/bin/bash
cd "$(dirname "$0")/.." || exit 1
for f in sections_before_rewrite/*.tex; do
  echo "== $(basename "$f")"
  git diff --no-index --word-diff=plain "$f" "sections/$(basename "$f")" | grep -E '\[-|\{\+' | head -80
done
python3 - <<'PY'
import re, glob, os
WORDS = ["may", "might", "could", "whether", "suggest", "first", "only", "all", "most", "largest", "best",
         "as quoted", "preprint", "was found", "not found", "according to", "described by", "reported"]
for f in sorted(glob.glob("sections_before_rewrite/*.tex")):
    a, b = open(f).read().lower(), open(os.path.join("sections", os.path.basename(f))).read().lower()
    diff = {w: (len(re.findall(rf"\b{w}\b", a)), len(re.findall(rf"\b{w}\b", b))) for w in WORDS}
    print(os.path.basename(f), {w: v for w, v in diff.items() if v[0] != v[1]})
PY
