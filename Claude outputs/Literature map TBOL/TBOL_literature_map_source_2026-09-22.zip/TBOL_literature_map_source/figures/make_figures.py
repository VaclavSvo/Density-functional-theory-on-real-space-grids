#!/usr/bin/env python3
"""Figures for the TBOL literature map.

Produces, in this folder:
  fig_crossover.pdf/.png   single-particle crossover of the lowest supercell band vs Omega/J
                           (data: grid.csv, the project's tbol_feasibility band grid)
  fig_crossover_data.csv   every plotted point, values copied as strings from grid.csv,
                           with the facts-ledger id each point rests on
  fig_coverage.pdf/.png    coverage matrix of the TBOL literature (studies x aspects)
  coverage_matrix.csv      the matrix cells with the ledger / inventory justification

Model behind grid.csv (facts_ledger.md header): two-component plane-wave bands,
E_cut = 60, units a = 1 and E_R; J(V0) = 0.086222, 0.030820, 0.012253 E_R at V0 = 4, 8, 12
(ledger F181). No interactions, trap or temperature.

Run:  python3 make_figures.py      (matplotlib, Agg backend; no network)
"""
import csv
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import matplotlib.ticker  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402
from matplotlib.patches import Patch, Polygon, Rectangle  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))

# Map palette
BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
INK, MUTED, RULE = "#0b0b0b", "#898781", "#c3c2b7"

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 8.5,
    "axes.labelsize": 8.5,
    "axes.titlesize": 8.5,
    "xtick.labelsize": 7.5,
    "ytick.labelsize": 7.5,
    "legend.fontsize": 7.5,
    "axes.edgecolor": MUTED,
    "axes.labelcolor": INK,
    "xtick.color": MUTED,
    "ytick.color": MUTED,
    "xtick.labelcolor": INK,
    "ytick.labelcolor": INK,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.linewidth": 0.6,
    "xtick.major.width": 0.6,
    "ytick.major.width": 0.6,
    "xtick.minor.width": 0.4,
    "ytick.minor.width": 0.4,
    "pdf.fonttype": 42,
    "savefig.dpi": 200,
})


def save(fig, stem):
    fig.savefig(os.path.join(HERE, stem + ".pdf"), bbox_inches="tight")
    fig.savefig(os.path.join(HERE, stem + ".png"), dpi=200, bbox_inches="tight")
    plt.close(fig)
    print("wrote", stem + ".pdf", stem + ".png")


# ----------------------------------------------------------------------------
# (a) crossover figure
# ----------------------------------------------------------------------------

# Ledger lines that transcribe individual grid.csv rows (m = 8 only; D §4 table)
ROW_LEDGER = {
    (8, 8, "0.1"): "F190", (8, 8, "0.2"): "F191", (8, 8, "0.3"): "F192",
    (8, 8, "0.5"): "F193;F212;F227", (8, 8, "0.7"): "F194;F208", (8, 8, "1"): "F195",
    (8, 8, "1.5"): "F196", (8, 8, "3"): "F197",
    (8, 12, "0.1"): "F198", (8, 12, "0.2"): "F199", (8, 12, "0.3"): "F200",
    (8, 4, "1"): "F201;F213", (8, 4, "1.5"): "F202", (8, 4, "3"): "F203", (8, 4, "10"): "F204",
}
# Ledger lines that cover a whole series
SERIES_LEDGER = {
    (8, 8): "F205;F209;F214;F223;F229",
    (8, 12): "F205;F207;F215",
    (8, 4): "F205;F215",
    (6, 8): "F206", (6, 12): "F206", (6, 4): "F206",
}
GRID_LEDGER = "F186;F187"  # grid.csv shape and coverage (every row)

V0_STYLE = {  # colour + marker (marker is the secondary encoding for the low-contrast aqua)
    4: dict(color=AQUA, marker="^", label=r"$V_0 = 4\,E_R$"),
    8: dict(color=BLUE, marker="o", label=r"$V_0 = 8\,E_R$"),
    12: dict(color=ORANGE, marker="s", label=r"$V_0 = 12\,E_R$"),
}
J_EXACT = {4: "0.08622244678", 8: "0.03082009596", 12: "0.01225304752"}  # grid.csv col J (F181)
OMEGA_R_EXPT = "0.5"  # E_r, Meng et al. path III threshold (F032)
WINDOW = (5.0, 25.0)  # Omega/J window (F209, C4 definition)


def load_grid():
    with open(os.path.join(HERE, "grid.csv"), newline="") as fh:
        rows = list(csv.DictReader(fh))
    assert len(rows) == 104 and len(rows[0]) == 47, (len(rows), len(rows[0]))
    return rows


def crossover(rows):
    series = {}
    for r in rows:
        m, v0 = int(r["m"]), int(r["V0"])
        if m not in (6, 8) or float(r["Omega"]) == 0.0:
            continue  # log x: Omega = 0 (the reference point W1 = W1_fold0) is not plotted
        series.setdefault((m, v0), []).append(r)
    for k in series:
        series[k].sort(key=lambda r: float(r["Omega"]))

    # threshold position from the grid's own J (0.5 / 0.03082009596 = 16.22...)
    x_thr = float(OMEGA_R_EXPT) / float(J_EXACT[8])
    print("Omega_R threshold at Omega/J =", f"{x_thr:.4g}", "(V0 = 8, J =", J_EXACT[8], ")")

    panels = [
        ("W1_over_W1_fold0", r"$W_1/W_1(\Omega{=}0)$", "(a) lowest-band width"),
        ("nG_PR", r"participation ratio of $|\psi_\Gamma|^2$", "(b) band-bottom localisation"),
        ("mass_ratio_Gamma", r"$m/m^*$ at $\Gamma$", "(c) inverse effective mass"),
    ]
    fig, axes = plt.subplots(1, 3, figsize=(6.1, 2.75))
    out_rows = []
    for ax, (col, ylab, tag) in zip(axes, panels):
        ax.axvspan(*WINDOW, color=RULE, alpha=0.35, lw=0, zorder=0)
        ax.axvline(x_thr, color=INK, ls=":", lw=0.9, zorder=1)
        for m in (6, 8):
            for v0 in (4, 8, 12):
                pts = series[(m, v0)]
                xs = [float(p["Omega_over_J"]) for p in pts]
                ys = [float(p[col]) for p in pts]
                st = V0_STYLE[v0]
                if m == 8:
                    ax.plot(xs, ys, color=st["color"], lw=1.6, marker=st["marker"], ms=3.6,
                            mec="white", mew=0.5, zorder=4)
                else:
                    ax.plot(xs, ys, color=st["color"], lw=1.0, alpha=0.35, marker=st["marker"],
                            ms=2.6, mew=0, zorder=3)
                for p in pts:
                    key = (m, v0, p["Omega"])
                    out_rows.append({
                        "panel": tag.split()[0], "column": col, "m": p["m"], "V0": p["V0"],
                        "Omega": p["Omega"], "Omega_over_J": p["Omega_over_J"], "value": p[col],
                        "ledger": ";".join(x for x in (ROW_LEDGER.get(key), SERIES_LEDGER[(m, v0)],
                                                        GRID_LEDGER) if x),
                    })
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.set_xlim(0.025, 1.3e3)
        ax.set_xlabel(r"$\Omega/J$")
        ax.set_ylabel(ylab)
        ax.grid(axis="x", which="major", color=RULE, lw=0.4, alpha=0.7)
        ax.set_title(tag, loc="left", fontsize=7.8, color=INK, pad=4)
        ax.xaxis.set_major_locator(matplotlib.ticker.LogLocator(base=10, numticks=10))
        ax.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(
            lambda v, _: {0.1: "0.1", 1: "1", 10: "10", 100: "100", 1000: "1000"}.get(round(v, 3), "")))
        ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
    # window + threshold labels (panel a only)
    axes[0].set_ylim(1.5e-6, 3)
    axes[1].set_ylim(2e-3, 1.1)
    axes[2].set_ylim(1e-6, 1.5)

    handles = [Line2D([], [], color=V0_STYLE[v]["color"], marker=V0_STYLE[v]["marker"], lw=1.6, ms=4,
                      mec="white", mew=0.5, label=V0_STYLE[v]["label"]) for v in (4, 8, 12)]
    handles += [
        Line2D([], [], color=MUTED, lw=1.6, label=r"$m = 8$ ($\theta = 14.25^\circ$)"),
        Line2D([], [], color=MUTED, lw=1.0, alpha=0.4, label=r"$m = 6$ ($\theta = 18.92^\circ$)"),
        Line2D([], [], color=INK, ls=":", lw=0.9,
               label=r"$\Omega_R = 0.5\,E_r$ (Meng et al., $V_0 = 8\,E_r$): $\Omega/J = 16.2$"),
        Patch(facecolor=RULE, alpha=0.35, lw=0, label=r"window $\Omega/J = 5$–25"),
    ]
    # legend is filled column-major: (V0=4, m=8) (V0=8, m=6) (V0=12, threshold) (window)
    handles = [handles[i] for i in (0, 3, 1, 4, 2, 5, 6)]
    fig.tight_layout(rect=(0, 0.2, 1, 1), w_pad=1.2)
    fig.legend(handles=handles, loc="lower center", ncol=4, frameon=False, bbox_to_anchor=(0.5, 0.045),
               handlelength=1.8, columnspacing=0.9, fontsize=6.9)
    fig.text(0.5, 0.0, "single-particle bands; no interactions, trap or temperature; computed for this map "
             "from grid.csv", ha="center", va="bottom", fontsize=6.8, color=MUTED)
    save(fig, "fig_crossover")

    with open(os.path.join(HERE, "fig_crossover_data.csv"), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(out_rows[0].keys()))
        w.writeheader()
        w.writerows(out_rows)
    print("wrote fig_crossover_data.csv,", len(out_rows), "points")
    return out_rows


# ----------------------------------------------------------------------------
# (b) coverage matrix
# ----------------------------------------------------------------------------

ASPECTS = [
    ("omega", "Rabi / uniform Ω coupling"),
    ("bosons", "bosons"),
    ("square", "square lattice"),
    ("inter", "interactions"),
    ("exc", "excitations / Bogoliubov"),
    ("fs", "superfluid fraction $f_s$"),
    ("T", "$T > 0$"),
    ("dyn", "real-time dynamics / ramps"),
    ("trap", "trap"),
    ("expt", "experiment"),
]

# cell codes: Y treated, P partly / single-particle only, N not treated (not in ledger/inventory),
#             U unknown (drawn empty)
# fields: key, row label, preprint?, {aspect: code}, justification
STUDIES = [
    ("gonzaleztudela2019", "González-Tudela 2019", False,
     dict(omega="Y", bosons="P", square="Y", inter="N", exc="N", fs="N", T="N", dyn="N", trap="N", expt="N"),
     "F084 (square state-dependent lattices, Gaussian-Wannier TB with J_perp ∝ Ω; partly verified), F219; "
     "inventory: band narrowing only -> single-particle (bosons = P)"),
    ("salamon2020", "Salamon 2020", False,
     dict(omega="P", bosons="N", square="Y", inter="N", exc="N", fs="N", T="N", dyn="N", trap="N", expt="N"),
     "F088 (square lattice; spatially modulated Raman coupling, not uniform -> omega = P); "
     "inventory: fermionic-atom proposal (bosons = N)"),
    ("luo2021", "Luo 2021", False,
     dict(omega="Y", bosons="N", square="N", inter="Y", exc="N", fs="N", T="N", dyn="N", trap="N", expt="N"),
     "F085 (hexagonal spin-twisted lattices, uniform clock-laser Ω), F086, F087 (fermionic LO superfluid: "
     "interactions = Y, fermions -> bosons = N; no f_s stated)"),
    ("meng2023", "Meng 2023", False,
     dict(omega="Y", bosons="Y", square="Y", inter="Y", exc="P", fs="P", T="U", dyn="P", trap="Y", expt="Y"),
     "F001 (87Rb), F006 (two orthogonal beams per lattice, square), F018-F019 (microwave Ω_R), F016/F036 "
     "(U/t, SU(2) GPE); exc = P: microwave band spectroscopy only (F015, F024); fs = P: SF/SF-II from TOF "
     "coherence, no f_s (F025, F027, F028); T = unknown: real gas at T > 0 but T not stated (F013, F038); "
     "dyn = P: Rabi oscillations and ramp sequence (F020, F022), no ramp study; trap = Y: omega_z, N (F012, "
     "F014; radial trap not stated F013); expt = Y"),
    ("paul2023", "Paul 2023", False,
     dict(omega="P", bosons="P", square="U", inter="N", exc="N", fs="N", T="N", dyn="P", trap="N", expt="N"),
     "F053, F243 (single-particle multifractality; interlayer coupling as effective disorder, tight-binding "
     "form -> omega = P; single particle -> bosons = P); dyn = P: single-particle dynamics/transport "
     "(inventory title 'Particle dynamics and ergodicity-breaking', F243); square = unknown (not stated in "
     "ledger)"),
    ("johnstone2024", "Johnstone 2024", False,
     dict(omega="N", bosons="Y", square="U", inter="Y", exc="N", fs="Y", T="Y", dyn="N", trap="N", expt="N"),
     "F074 (single-component bosons, summed potential: no coupling; worm QMC at k_BT = 0.01-0.04 E_r), "
     "F076 (Mott plateaus, thin SF domains), F077 (f_s = Υ/ρ), F334 (grand-canonical boxes, no trap); "
     "square = unknown: theta = 28.07° = 2 arctan(1/4) suggests square lattices but the ledger does not say so"),
    ("zeng2025", "Zeng 2025", False,
     dict(omega="N", bosons="Y", square="U", inter="Y", exc="N", fs="N", T="N", dyn="U", trap="P", expt="N"),
     "F054 (vanishing interlayer tunnelling -> omega = N; Bose-Hubbard; Gutzwiller; 37x37 box trap -> "
     "trap = P), F055, F056; F044 (T = 0, partly verified); dyn = unknown: arXiv v2 title 'Dynamical Moiré "
     "Systems' (F241) but no dynamics in the ledger; square = unknown: angles 36.87°, 22.62°, 7.63° are "
     "square-lattice commensurate angles but not stated"),
    ("wang2025", "Wang 2025", True,
     dict(omega="Y", bosons="P", square="P", inter="N", exc="N", fs="N", T="N", dyn="N", trap="N", expt="N"),
     "F069, F070 (uniform Ω projected on lowest band -> scalar moiré potential; single particle); "
     "square = P: derivation for the 3-D cubic quasi-moiré crystal, application to 2-D square TBOL is the "
     "docs' step (F069, F244); arXiv preprint"),
    ("sui2025", "Sui 2025", False,
     dict(omega="Y", bosons="P", square="N", inter="N", exc="N", fs="N", T="N", dyn="N", trap="N", expt="N"),
     "F079 (honeycomb, uniform Ω, 'square lattice not treated'; flat-band single-particle study -> "
     "bosons = P)"),
    ("paul2025", "Paul 2025", False,
     dict(omega="Y", bosons="Y", square="Y", inter="Y", exc="N", fs="P", T="N", dyn="N", trap="N", expt="N"),
     "F045 (two-layer square Bose-Hubbard), F047 (t_perp from microwave/Raman coupling), F048, F050 (T = 0, "
     "homogeneous; partly verified), F051 (percolation SF proxy -> fs = P), F052 (no Bogoliubov, no f_s, "
     "no T > 0, no trap, dynamics left open; absence claim partly verified), F089"),
    ("zhang2025b", "Zhang 2025", False,
     dict(omega="N", bosons="Y", square="U", inter="Y", exc="N", fs="Y", T="U", dyn="N", trap="N", expt="N"),
     "F080 (dipolar hard-core bosons, twisted bilayer without tunnelling -> omega = N; path-integral QMC "
     "rho_s -> fs = Y; insulating islands at 5.21°); T = unknown: worm QMC runs at finite T but no "
     "temperature in the ledger; square = unknown (lattice not stated)"),
    ("fan2025", "Fan 2025", True,
     dict(omega="Y", bosons="Y", square="N", inter="Y", exc="N", fs="N", T="N", dyn="Y", trap="Y", expt="N"),
     "F065 (two-component GPE, hexagonal, Ω = E_R, V0 = 4 E_R, trap 2π×(20,20,1000) Hz, Floquet g(t)), "
     "F066, F067; arXiv preprint"),
    ("ding2025", "Ding 2025", False,
     dict(omega="U", bosons="Y", square="U", inter="Y", exc="N", fs="P", T="N", dyn="Y", trap="N", expt="N"),
     "F057 (large-detuning 45° quasicrystal limit, U-quench, time-dependent Gutzwiller; partly verified), "
     "F242 (Bose glass reentrance; percolated SF network -> fs = P; quench dynamics verified -> dyn = Y); "
     "omega = unknown: map Table 'variants' lists no coupling, D §2.1 a large-detuning (Ω-derived) limit "
     "not in the abstract; square = unknown: 45° quasicrystal implies square lattices, not stated"),
    ("johnstone2025", "Johnstone 2025", False,
     dict(omega="N", bosons="P", square="U", inter="N", exc="N", fs="N", T="N", dyn="N", trap="N", expt="N"),
     "F078 (fitted tight-binding models for the summed single-component potential -> omega = N, "
     "single particle -> bosons = P); square = unknown (as johnstone2024)"),
    ("cheng2026", "Cheng 2026", False,
     dict(omega="N", bosons="Y", square="N", inter="Y", exc="N", fs="N", T="N", dyn="N", trap="N", expt="N"),
     "F068 (1-D PT-symmetric bichromatic GPE, nonlinear Bloch bands, weak repulsion broadens the moiré "
     "flat band; 1-D -> square = N; no interlayer coupling)"),
    ("xie2026", "Xie 2026", True,
     dict(omega="N", bosons="Y", square="N", inter="Y", exc="N", fs="N", T="N", dyn="N", trap="N", expt="N"),
     "F260 (1-D moiré Bose-Hubbard, DMRG, 'local supersolid'; 1-D -> square = N); inventory; arXiv preprint"),
    ("wan2026", "Wan 2026", False,
     dict(omega="Y", bosons="P", square="Y", inter="N", exc="N", fs="N", T="N", dyn="N", trap="N", expt="N"),
     "F071 (same model as meng2023 with detuning δ; imbalanced limit -> Hofstadter model; single particle "
     "-> bosons = P, interactions = N), F072, F240"),
    ("yang2026", "Yang 2026", True,
     dict(omega="Y", bosons="N", square="N", inter="Y", exc="P", fs="N", T="N", dyn="N", trap="N", expt="N"),
     "F059 (fermions, honeycomb, uniform microwave Ω; partly verified: not in abstract), F060, F062 "
     "(Hartree-Fock), F063 (ED many-body gap ~1e-3 E_R -> exc = P); arXiv preprint"),
    ("walkling2026", "Walkling 2026", False,
     dict(omega="U", bosons="P", square="Y", inter="N", exc="N", fs="N", T="N", dyn="P", trap="N", expt="N"),
     "F257 (two square lattices, one continuously rotated = multi-frequency drive -> dyn = P; ring-shaped "
     "localised states; single particle -> bosons = P); omega = unknown: coupling between the two lattices "
     "not described in the ledger"),
]
CODE_WORD = {"Y": "treated", "P": "partly", "N": "no", "U": "unknown"}


def coverage():
    # csv
    with open(os.path.join(HERE, "coverage_matrix.csv"), "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["key", "label", "preprint"] + [a for a, _ in ASPECTS] + ["justification"])
        for key, label, pre, cells, why in STUDIES:
            w.writerow([key, label, "yes" if pre else "no"] + [CODE_WORD[cells[a]] for a, _ in ASPECTS] + [why])
    print("wrote coverage_matrix.csv,", len(STUDIES), "rows")

    n_r, n_c = len(STUDIES), len(ASPECTS)
    cell = 0.2  # inches per cell
    left, top, bottom = 1.35, 1.45, 0.4
    fig_w = min(6.3, left + n_c * cell * 1.9 + 0.2)
    fig = plt.figure(figsize=(fig_w, top + n_r * cell + bottom))
    ax = fig.add_axes([left / fig_w, bottom / fig.get_figheight(), (n_c * cell * 1.9) / fig_w,
                       (n_r * cell) / fig.get_figheight()])
    colw = 1.0
    s = 0.62  # tile size in cell units
    for i, (key, label, pre, cells, _) in enumerate(STUDIES):
        y = n_r - 1 - i
        if i % 2 == 0:
            ax.add_patch(Rectangle((-0.5, y - 0.5), n_c * colw, 1, facecolor="#f3f2ee", lw=0, zorder=0))
        for j, (a, _) in enumerate(ASPECTS):
            x = j * colw
            c = cells[a]
            x0, y0 = x - s / 2, y - s / 2
            if c in ("N", "U"):
                ax.add_patch(Rectangle((x0, y0), s, s, facecolor="white", edgecolor=RULE, lw=0.6, zorder=2))
            elif c == "Y":
                ax.add_patch(Rectangle((x0, y0), s, s, facecolor=BLUE, edgecolor=BLUE, lw=0.6, zorder=2))
            elif c == "P":
                ax.add_patch(Rectangle((x0, y0), s, s, facecolor="white", edgecolor=BLUE, lw=0.6, zorder=2))
                ax.add_patch(Polygon([(x0, y0), (x0 + s, y0), (x0, y0 + s)], closed=True,
                                     facecolor=BLUE, lw=0, zorder=3))
    ax.set_xlim(-0.5, n_c * colw - 0.5)
    ax.set_ylim(-0.5, n_r - 0.5)
    ax.set_aspect("auto")
    for sp in ax.spines.values():
        sp.set_visible(False)
    ax.tick_params(length=0)
    ax.set_yticks(range(n_r))
    ax.set_yticklabels([lab + (" p" if pre else "") for _, lab, pre, _, _ in reversed(STUDIES)], fontsize=7.8)
    # mark the experiment row label in bold ink
    for t in ax.get_yticklabels():
        if t.get_text().startswith("Meng"):
            t.set_fontweight("bold")
    ax.xaxis.tick_top()
    ax.set_xticks([j * colw for j in range(n_c)])
    ax.set_xticklabels([lab for _, lab in ASPECTS], rotation=45, ha="left", va="bottom",
                       rotation_mode="anchor", fontsize=7.5, linespacing=0.95)
    # legend drawn by hand so the half tile matches the matrix glyph
    lax = fig.add_axes([0, 0, 1, 0.3 / fig.get_figheight()])
    lax.set_xlim(0, fig_w)
    lax.set_ylim(0, 0.3)
    lax.axis("off")
    t = 0.12  # tile side in inches
    items = [("Y", "treated"), ("P", "partly / single-particle only"),
             ("N", "not treated / not stated")]
    x = 0.1
    for code, text in items:
        y0 = 0.09
        if code == "Y":
            lax.add_patch(Rectangle((x, y0), t, t, facecolor=BLUE, edgecolor=BLUE, lw=0.6))
        elif code == "P":
            lax.add_patch(Rectangle((x, y0), t, t, facecolor="white", edgecolor=BLUE, lw=0.6))
            lax.add_patch(Polygon([(x, y0), (x + t, y0), (x, y0 + t)], closed=True, facecolor=BLUE, lw=0))
        else:
            lax.add_patch(Rectangle((x, y0), t, t, facecolor="white", edgecolor=RULE, lw=0.6))
        tx = lax.text(x + t + 0.06, y0 + t / 2, text, va="center", ha="left", fontsize=7, color=INK)
        fig.canvas.draw()
        bb = tx.get_window_extent().transformed(lax.transData.inverted())
        x = bb.x1 + 0.22
    lax.text(x - 0.05, 0.09 + t / 2, "p = preprint", ha="left", va="center", fontsize=7, color=MUTED)
    save(fig, "fig_coverage")


if __name__ == "__main__":
    rows = load_grid()
    crossover(rows)
    coverage()
