# Corrections made by the checks (phase 4, map 2, 2026-09-23)

Seed for the README. One line per correction to the research briefs, the research agents' rows or the Project docs (bibliographic data, claim wording, attributions), and one line per statement the checks could not confirm. Sources: `verify/batch_1.md` … `batch_7.md`, `verify/batch_8_secondpass.md`, `verify/batch_9_leftovers.md` (paths relative to `work/`). Keys are the final keys (renames in `verify/progress.md`, "Key renames"). Ledger ids refer to `facts_ledger.md`.

## Bibliographic corrections

- bradley2014spgpe → rooney2014: authors S. J. Rooney, P. B. Blakie, A. S. Bradley (first author Rooney, not Bradley); PRE 89, 013302 (2014), arXiv:1310.0161.
- x2407_17558 → geier2025: K. T. Geier, J. Maki, A. Biella, F. Dalfovo, S. Giorgini, S. Stringari, "Superfluidity and sound propagation in disordered Bose gases", PRR 7, 013187 (2025) (venue from a listing).
- gaul2011: authors Christopher Gaul and Cord A. Müller (key kept); venue not seen, kept as a preprint.
- fabbri2009: authors N. Fabbri, D. Clément, L. Fallani, C. Fort, M. Modugno, K. M. R. van der Stam, M. Inguscio (first author Fabbri confirmed; key kept).
- zhu2023: authors Zhaoxuan Zhu, Hepeng Yao, Laurent Sanchez-Palencia, arXiv:2210.15526 (submitted 2022; venue not seen).
- nagao2021: authors Kazuma Nagao, Yosuke Takasu, Yoshiro Takahashi, Ippei Danshita; arXiv:2008.09900; PRR 3, 043091 (2021).
- hagley1999: full author list E. W. Hagley, L. Deng, M. Kozuma, M. Trippenbach, Y. B. Band, M. Edwards, M. R. Doery, P. S. Julienne, K. Helmerson, S. L. Rolston, W. D. Phillips; PRL 83 (16), 3112–3115.
- dutta2015: full author list O. Dutta, M. Gajda, P. Hauke, M. Lewenstein, D.-S. Lühmann, B. A. Malomed, T. Sowiński, J. Zakrzewski; DOI 10.1088/0034-4885/78/6/066001 (listing); the arXiv title has no ": a review".
- jendrzejewski2012: authors 4–10 confirmed; arXiv:1108.0137 added.
- fletcher2015: arXiv:1501.02262 added; authors 6–7 (K. G. H. Viebahn, Z. Hadzibabic) confirmed.
- du2010: full names (X. Du, Shoupu Wan, Emek Yesilada, C. Ryu, D. J. Heinzen, Zhaoxin Liang, Biao Wu); DOI 10.1088/1367-2630/12/8/083025 now read (was inferred).
- hung2010: authors Chen-Lung Hung, Xibo Zhang, Nathan Gemelke, Cheng Chin confirmed; arXiv:1003.0855; title "Slow mass transport and statistical evolution of an atomic gas across the superfluid–Mott-insulator transition" (not a compressibility paper).
- ciardi2022: PRA 105, L011301 (2022), not "PRL 2023" as in the phase-3 brief; arXiv:2109.03215 tied to title and authors (Matteo Ciardi, Tommaso Macrì, Fabio Cinti).
- greiner2002: an arXiv record exists, arXiv:2506.21303 (posted 2025, journal-ref Nature 415, 39 (2002)); batch 4's "no arXiv version" is superseded.
- steinhauer2002: arXiv title "The Excitation Spectrum of a Bose-Einstein Condensate" (leading "The"); arXiv ID is cond-mat/0111438, not cond-mat/0202029.
- stamperkurn1999: arXiv:cond-mat/9906035 added.
- kollath2004: arXiv:cond-mat/0310388 added (arXiv title "… trapped 1D bosons …"); cond-mat/0312003 is a different paper (Laburthe Tolra et al.).
- gerbier2005a: arXiv:cond-mat/0503452; gerbier2005b: arXiv:cond-mat/0507087 (both new).
- gerbier2008: arXiv:0808.2212 is correct (not 0808.1798).
- spielman2008: arXiv:0803.3797 (new).
- pollet2010: arXiv:1003.2655 (new).
- billy2008: arXiv:0804.1621 (new; arXiv title writes "matter-waves").
- kosterlitz1973: pages 1181–1203; DOI 10.1088/0022-3719/6/7/010 (listing).
- gross1961: DOI 10.1007/BF02731494 confirmed by listing; listings disagree on the end page (457 vs 477).
- pitaevskii1961: Sov. Phys. JETP 13, No. 2 (Aug 1961), 451 (publisher archive listing); the Russian original ZhETF 40, 646 is not confirmed.
- choi2016: DOI 10.1126/science.aaf8834 (listing).
- guimaraes2026: DOI 10.1103/k9ym-r23v tied to this title in PRA by a listing; the link to 114, 023312 and arXiv:2605.06171 is not seen on one record.
- williams2008: page 16977 kept (ADS bibcode 2008OExpr..1616977W); the "16, 5465–5470" returned in batch 3 is judged a fetch error.
- gauthier2016: the bib title is the arXiv v2 title; v1 was "Configurable microscopic optical potentials for Bose-Einstein condensates using a digital-micromirror device".
- spielman2007: the arXiv title reads "The Mott insulator transition in a two dimensional atomic Bose gas"; PRL 98, 080404 not confirmed.
- sunami2022, clade2009, menotti2003, fallani2007: arXiv titles differ from the bib titles (abbreviations, hyphenation, "1D", "Towards a Bose-Glass of ultracold atoms in a disordered crystal of light"); the published titles were not seen.
- christodoulou2021: the arXiv title spells out "Berezinskii–Kosterlitz–Thouless"; nature.com has "BKT" (bib kept).
- sanchezpalencia2010: a Progress Article in Nat. Phys., not a review.
- yu2024 / song2026: the bib had "Lee Reeve" (yu2024) and "Leanne Reeve" (song2026, confirmed on arXiv); yu2024 now "L. Reeve" as on nature.com.
- perrin2026: author Hélène Perrin; lecture notes of the IV School on Light and Cold Atoms, ICTP-SAIFR, São Paulo, 20–31 Oct 2025; posted Sep 2026 (the aggregator listing is no longer used).
- rabec2026: PRL 136, 133401 (2026) and DOI 10.1103/g494-rj5k confirmed on the published PDF.

## Claim and wording corrections

- F311 (Steinhauer 2002): μ/h = 2.02 ± 0.09 kHz on the arXiv version (not 1.91 ± 0.09 kHz; the 1.91 is unresolved); the k range 0.5–8.0 µm⁻¹ is not on the page and was removed (only 3° ≤ θ ≤ 130°).
- F319 (Ville 2018): uncertainties added: box 30(1) × 38(1) µm, g̃ = 0.16(1), T/T_c = 0.37(12).
- F320 (Ville 2018): c = 1.90(9) mm/s comes from standing-wave resonances in a separate experiment; it must not be compared with 1.49(3) mm/s.
- F344 (Ville 2017): the compressed plane reaches ω_z/2π > 10 kHz ("frequencies larger than"), not "= 10 kHz".
- F328 (Hadzibabic–Dalibard 2011): g̃ "varies between ∼10⁻¹ and ∼10⁻²"; g̃ = 0.15 is credited to the ENS experiment (not "Paris/Cambridge"); the brief's 0.13 is not in the review; "0.02 (NIST)" not found.
- F369 (Greiner 2002): the paper says "at a potential depth of around 13 E_r the interference maxima no longer increase in strength … at a potential depth of 22 E_r no interference pattern is visible at all"; the peaks do not "disappear beyond 13 E_r"; U/J ≈ 36 at 13 E_r is now from the primary source (arXiv:2506.21303), not only as quoted by Zwerger.
- F373 (Kühner–Monien 1998): t_c = 0.277 ± 0.01 gives (U/t)_c ≈ 3.61; the brief's ≈ 3.3 is not this paper's value.
- F376 (Mark 2011): "quantitatively measure number-dependent shifts in the excitation spectrum caused by effective multi-body interactions" replaces "number-dependent U from modulation-spectroscopy resonances" (a tool paraphrase).
- F382 (Greiner 2001): "up to 3000 lattice sites are populated" (not "> 3000 tubes"); the ramp is "2 ms after a 2 ms hold time".
- F386 (Fallani 2007): Δ is "the maximum energy difference between neighboring sites" (3.2 kHz ≃ 1.7U), not a site-energy spread; s₂ = 2.5 not found.
- F400 (Gautier 2021): the Bose glass has "f_s ≈ 0", not "f_s = 0".
- F124 (Nagao 2021): the paper says the GP-based TWA is "not suitable … in the strongly interacting limit"; "unit filling near Mott lobes", "filling ≥ 3" and "hand that corner to QMC" are the project's inference.
- F305 (Burger 2001): the paper does not name the Landau criterion; its reading is the spontaneous emission of elementary excitations.
- F345 (Fletcher 2015): the verbatim phrase is "without any free parameters".
- F372 (Capogrosso-Sansone 2008): the quotation starts "The critical point …" (capital; cosmetic).
- F235 / F259 (f_s = m/m*): Chauveau et al. 2023 themselves state that the superfluid fraction "exactly coincides with the ratio m/m*_x = f_s,x"; the docs' "our step" / "the map's own combination" should credit them for the identity (only its combination with Taylor–Zaremba is the project's).

## Misattributions

- Weimer et al., PRL 114, 095301 (2015) is "Critical Velocity in the BEC-BCS Crossover" (⁶Li, fermions), not a 2D Bose-gas critical-velocity paper; excluded (F322).
- Kondov et al., Science 334, 66 (2011) uses a spin-polarised ⁴⁰K Fermi gas; excluded (F407); for 3-D Anderson localisation of bosons use jendrzejewski2012, semeghini2015.
- Hung et al., PRL 104, 160403 (2010) is "Slow mass transport and statistical evolution …", not a compressibility paper; the in-situ compressibility paper is gemelke2009 (F404).
- Ciardi, Macrì, Cinti is PRA 105, L011301 (2022); the brief's "PRL 2023?" is a different paper, zhu2023 (F405).
- Kühner–Monien's 1D critical point is (U/t)_c ≈ 3.61, not 3.3 (F373); 3.37 is probably Kühner–White–Monien 2000 (not checked); Zwerger quotes 3.84 (F368).
- Steinhauer et al.: μ/h = 2.02 kHz on the arXiv version, not 1.91 kHz (possibly a mix-up with Stöferle's second-peak ratio 1.91 ± 0.04) (F311).
- Greiner et al. 2002: the "≈ 13 E_r" is where the interference maxima stop growing, not where they disappear (F369).
- Nagao et al. 2021: the unit-filling / filling ≥ 3 / QMC advice is the project's inference, not the paper's (F124).
- Burger et al. 2001: the Landau criterion is the brief's label, not the paper's wording (F305).
- Hadzibabic–Dalibard 2011: g̃ = 0.15 is the ENS value, not "Paris/Cambridge" (F328).

## Statements the checks could not confirm

- Hadzibabic et al. 2006: the coherence-decay exponent α ≈ 0.25 → 0.5 (nature.com abstract only; arXiv cond-mat/0605291 not rendered).
- Andrews et al. 1997: the fringe period (~15 µm) (science.org refused; the Varenna notes cond-mat/9904034 give no sentence); the source rests on listings only (F356).
- Christodoulou et al. 2021: first and second sound speeds and T_c (nature.com and ar5iv texts returned without numbers).
- Greiner et al. 2002: the Mott-gap values (resonance energies) were not returned verbatim.
- D'Errico et al. 2014: the U range up to 44J (seen 0.35J–26J "and beyond"); Δ up to 9.5J (≈ 10J) (F389).
- Bloch, Dalibard, Zwerger 2008: section IV (SF–MI observables, (U/J)_c values, visibility, gap) never returned (three attempts); RMP 80, 885 not seen.
- Billy et al. 2008 and Roati et al. 2008: localisation lengths, speckle correlation length and the Δ/J at the crossover (abstract pages only; roati2008's arXiv 0804.2609 unconfirmed).
- Chomaz et al. 2015: the "0–5 defects" range (F343).
- Pasienski et al. 2010: the "re-entrant superfluid" sentence (returned truncated) (F387).
- Pollock–Ceperley 1987 (F402) and Fisher–Barber–Jasnow 1973 (F403): no primary text read (scan / listing only).
- Aftalion–Blanc–Jerrard 2007: the NCRI fraction (I₀ − I)/I₀ (F348); the ID 0705.2499 also surfaced in a search for Sepúlveda et al. (identity to confirm).
- Guimaraes & Sanchez-Palencia 2026: arXiv:2605.06171 ↔ DOI 10.1103/k9ym-r23v ↔ PRA 114, 023312 not seen on one record (F406).
- Song et al. 2026: html v1 dated 9 Sep 2026 vs "submitted 4 Sep 2026" in the evidence (F397).
- Rabec et al. 2026: the finite-temperature attribution of the small deviations at larger depth (F163).
- Journal volume/pages not seen on a primary record (arXiv record only, or listing only) for most APS papers: the per-source `\vpartial{…}` notes in `map/refs.bib` list them.


# Round-2 research corrections (phase 3b merge, 2026-09-23)

Reported by the round-2 agents (work/research/R4_findings.md … R7_findings.md); status `to check` until batches 10–12 confirm them. Ledger ids refer to work/facts_ledger.md.

## Bibliographic corrections (round 2)

- "Ozawa & Stringari, PRL 119, 250402 (2017)" (brief) is wrong: PRL 119, 250402 is Bombin, Boronat, Mazzanti, "Dipolar Bose supersolid stripes" (bombin2017, F536). The Ozawa–Stringari 2D-sound paper is arXiv:1310.3654 (ozawa2014, F534, F535); its venue PRL 112, 025302 (2014) is written from memory and is unconfirmed.
- Sunami et al. 2023, "Universal scaling of the dynamic BKT transition in quenched 2D Bose gases", is Science (DOI 10.1126/science.abq6753, arXiv:2209.13587), not "PRL 130" (sunami2023; volume/page 382, 443 from memory).
- gerbier2006 = Gerbier, Fölling, Widera, Mandel, Bloch, "Probing number squeezing of ultracold atoms across the superfluid–Mott insulator transition", PRL 96, 090401 (2006), arXiv:cond-mat/0511080: a third Gerbier paper, not "Interference pattern and visibility of a Mott insulator" (that is gerbier2005b, PRA 72, 053606; gerbier2005a is PRL 95, 050404).
- ernst2010: arXiv:0908.4242, arXiv title "Momentum-Resolved Bragg Spectroscopy in Optical Lattices" (different from the Nat. Phys. title); 7 authors read.
- gaul2011: Phys. Rev. A 83, 063629 (2011), DOI 10.1103/PhysRevA.83.063629 (listing); no longer a bare preprint.
- zhu2023: Phys. Rev. Lett. 130, 220402 (2023), DOI 10.1103/PhysRevLett.130.220402 (listing).
- ota2018a: arXiv:1712.05022 (arXiv title "Second sound in 2D Bose gas: from the weakly interacting to the strongly interacting regime").
- hung2011: arXiv:1009.0016 (title and authors on ar5iv).
- roati2008: arXiv:0804.2609 confirmed on the PDF (title and 9 authors).
- hadzibabic2006: arXiv:cond-mat/0605291 read (PDF).
- pasienski2010: arXiv:0908.1182, arXiv title without the leading "A"; deissler2010 arXiv:0910.5062; semeghini2015 arXiv:1404.3528; sanchezpalencia2010 arXiv:0911.0629; lucioni2011 arXiv title "… of a disordered interacting system"; gadway2011 and mark2011 author lists read; ozeri2005 pages 187–205 (institutional record).
- koehn2026 ("PRA xb42-j6px" in the brief) is Strathclyde (Kuhr group), not Cambridge: PRA 113, 043303 (2026); arXiv:2504.13040 v1 had a different title.
- menotti2003b (NJP 5, 112) gets a new key because menotti2003 (PRA 67, 053609) is taken.
- mendozacoto2025 (PRL 134, 136003) is a self-organised quantum quasicrystal (long-range interactions), off-target; kept, marked peripheral.
- singh2016 (PRA 93, 023634) simulates the Hamburg ⁶Li₂ molecular BEC (weimer2015, excluded): dropped; singh2017 (arXiv:1703.02024) is the 2D ⁸⁷Rb stirring theory.

## Claim and wording corrections (round 2)

- F326 (Hadzibabic–Dalibard 2011): the quasi-2D (frozen-z) condition is a_z ≪ ξ, λ/√(2π) (with ħω_z ≫ k_BT, gn); the "≫" of the phase-3 fetch and the phase-4 checkpoint was a rendering inversion (F506; status `corrected`; read by eye in batch 11).
- F328: desbuquois2012 (the ENS stirring experiment) has g̃ = 0.093 (F433, F510); the review's g̃ = 0.15 "as in the ENS experiment" refers to a different ENS setup. Both values are recorded.
- F299 (Ramanathan 2011): the arXiv PDF gives "v_c/c_eff ≈ 0.6 and is independent of c_eff" (F446); "no numerical v_c" applied to the abstract only.
- F294 (Onofrio 2000): "onset of a drag force", the force coming from the pressure difference across the moving beam (F ≃ gSnΔn), not "onset of a pressure gradient" (F425; status `corrected`).
- F334 / hadzibabic2006: the interference exponent α drops from 0.5 (high T) to 0.25 on cooling ("a sudden drop in α from 0.5 to 0.25"); "0.25 → 0.5" is the heating direction (F489, F490).
- F311 (Steinhauer 2002): μ/h = 2.02 ± 0.09 kHz in arXiv v1 as well (F571); 1.91 appears in no version read and is probably Stöferle's (1.91 ± 0.04) (F313).
- F389 (D'Errico 2014): "U = 44J" appears only in the Fig. 4(e) caption (exact diagonalisation), not as the experimental range (F616); pasienski2010 also has "U/t = 44" at s = 14 (F643).
- Christodoulou et al. 2021: ³⁹K, g̃ = 0.64(3), ω_z/2π = 5.5(1) kHz, T_c = 42(4) nK at n = 3.0(5) µm⁻², c_B ≈ 2.3 mm/s, D_s jumps from 0 to 4 (F493–F496); measured sound speeds only in figures.
- Hung et al. 2011: g̃ = 0.05–0.26 (a range, not a single 0.26) (F503).
- Fletcher et al. 2015: the critical point is expressed as N_c/N_c⁰ (critical vs ideal-gas atom number), not as D_c or T/T_BEC (F517).
- Tao et al. 2023: "near-perfect agreement with Leggett's expression" compares BdG theory with Leggett's formula, not a measurement; no numerical f_s in the text (F502; notes on F118, F243).
- Ville 2018 / Ota 2018: T/T_c = 0.37(12) belongs to ville2018; ota2018b has no "0.37 T_c" statement (F531); 1.90(9) mm/s is ville2018's standing-wave value at T/T_c = 0.41(7) (F498).
- Greiner 2002 (F369): the Mott-gap spectrum is now read (tilt resonance at ΔE = U, broad resonances from ≈ 13 E_r, narrow ones at 20 E_r, second at exactly 2×) (F541–F545).
- Three agent cross-references were wrong and are corrected in the ledger: R4-009 → R4-041, R4-015 → R4-062, R4-019 → R4-067.

## Misattributions (round 2)

- "0.37 c" (brief, credited to Frisch–Pomeau–Rica 1992): cite kwon2015, which quotes v_c = 0.37 c_s as the large-cylinder (R ≫ ξ) theory value (F470); the FPR attribution is unconfirmed (frisch1992 full text not read; raman1999 quotes FPR's √(2/11) c ≈ 0.42 c, F424, F455).
- Density dependence of v_c is measured in onofrio2000, not in raman1999.
- "T = 0.37 T_c" belongs to Ville et al. 2018, not to Ota et al. 2018.
- "44J": D'Errico 2014 has it only in a figure caption; Pasienski 2010 has U/t = 44; check which paper the docs mean.
- Steinhauer 2002 "1.91 kHz": not in any arXiv version; likely confused with Stöferle 2004's ratio 1.91(4).
- Aleiner, Altshuler, Shlyapnikov 2010 is specifically one-dimensional (not a general finite-T phase diagram).

## Open items from phase 4 answered by round 2 (to check)

- Hadzibabic 2006 exponent (now read, direction corrected); Christodoulou 2021 T_c (now read; sound speeds still figures only); Greiner 2002 Mott-gap values (now read); Billy 2008 σ_R = 0.26(3) µm and k_max σ_R = 0.65(9) (F611, F612; L_loc only in figures); Roati 2008 arXiv ID (confirmed; experimental Δ/J still not a number); Chomaz 2015 "between 0 and 5" (verbatim, F523); D'Errico 2014 "44J" (explained above).


# Round-2 checking corrections (phase 4b, 2026-09-23)

From the checkpoints `verify/batch_10.md` … `batch_15.md` (merged in `verify/progress.md`, `facts_ledger.md`, `sources_inventory.md`, `map/refs.bib`). One line per correction; ledger ids refer to `facts_ledger.md`.

## Bibliographic corrections (round-2 checks)

- sunami2023: Science 382 (6669), 443–447 (published 2023-10-26), DOI 10.1126/science.abq6753, read on the Oxford ORA record; volume and first page had been written from memory, end page added.
- navon2021: Nat. Phys. 17, 1334–1341 (2021), DOI 10.1038/s41567-021-01403-z, read on nature.com (end page and DOI added).
- ozawa2014: PRL 112, 025302 (2014) = DOI 10.1103/PhysRevLett.112.025302, from the APS URL in a search listing (no longer "from memory"; page not opened).
- saintjalm2019: PRX 9 (2), 021035 (2019), DOI 10.1103/PhysRevX.9.021035, read on the DOAJ record.
- bisset2009: an Erratum to PRA 79, 033626 exists (OSTI ETDEWEB 22072241); not read and not cited; noted in the bib; DOI 10.1103/PhysRevA.79.033626 from a listing.
- smerzi2002: the PRL has a live arXiv version, arXiv:cond-mat/0207172 (title and authors on ar5iv); the "no live arXiv version" of the phase-3b entry is withdrawn.
- burger2001: the 7-author list of the bib is confirmed by the ar5iv full-text header; the "5 authors" of batch 10 came from the arXiv abs metadata.
- lugan2007b: DOI 10.1103/PhysRevLett.99.180402 (listing) added.
- schulte2005: DOI 10.1103/PhysRevLett.95.170411 (listing) added; arXiv cond-mat/0507453 surfaced unlabelled in a listing and is not adopted.
- mendozacoto2025: arXiv:2407.21230 (v3 read); second author "M. Bonifacio" on the arXiv record (not "Paolo M."); affiliations MPI-PKS Dresden, UFSC Florianópolis, Univ. Augsburg.
- koehn2026: full author names (Lennart Koehn, Christopher Parsonage, Callum W. Duncan, Peter Kirton, Andrew J. Daley, Timon Hilker, Elmar Haller, Arthur La Rooij, Stefan Kuhr); all University of Strathclyde (Duncan also Aegiq Ltd, Sheffield; Daley also Oxford); nobody at Cambridge.
- rey2005: the published title "Bragg spectroscopy of ultracold atoms loaded in an optical lattice" is confirmed by the APS listing and the arXiv header; the alternative title in the phase-3b note is dropped.
- pollet2012: arXiv title "The Higgs mode in a two-dimensional superfluid" (leading "The"); PRL title "Higgs Mode in a Two-Dimensional Superfluid" (listing).
- steinhauer2003: the author list is shown on no record; bib author field reduced to "Steinhauer, J. and others" with a \vpartial note.
- dalibard2016: the chapters were read as the per-chapter PDFs on phys.ens.psl.eu (Cours2.pdf, Cours3.pdf, Cours4.pdf); these URLs are added next to the Collège de France combined PDF.
- DOIs from search listings added: gaunt2013, xu2006, huber2007, pollet2012, lugan2007a, sanchezpalencia2007, clement2005, fort2005, gurarie2009, chauveau2023.
- zhang2012: a fetch tool returned "Journal Reference: New J. Phys. 13, 045011 (2011)" for arXiv:1109.0344; it comes from the reference list (another Chin-group paper) and was not adopted (Science 335, 1070 kept).
- holzmann2008: the brief's title "Kosterlitz-Thouless-Berezinskii transition for interacting trapped bosons" is not PRL 100, 190402; that article is "Kosterlitz-Thouless Transition of the Quasi-Two-Dimensional Trapped Bose Gas" (as in the bib).
- sunami2022: the published title (PubMed listing) matches the bib's spelled-out title.
- Venues still not seen on any record (\vpartial notes): sengupta2005 (PRA 71, 033629), pollet2009 (PRL 103, 140402), yao2020 (PRL 125, 060401), podolsky2011 (PRB 84, 174522), holzmann2008b (EPL 82, 30001), schori2004 (PRL 93, 240402), fallani2008 (AAMOP 56, 119), lye2005 (PRL 95, 070401).
- frisch1992: not reached for this map (batches 10, 10b, 15); bibliographic data from the author's publication list only (\vpartial).

## Claim and wording corrections (round-2 checks)

- F421 (Raman 1999): the crossover is at about 1.6 mm/s; the condensate is almost completely depleted at about 6 mm/s (900 ms), not at 1.6 mm/s.
- F425 / F294 (Onofrio 2000): "A drag force arises due to the pressure difference across the moving object." ("object", not "beam"; not "pressure gradient").
- F444 (Fertig 2005): q_max ≈ π/5 holds for V < 2E_R; deeper lattices give a larger q_max, always < π/2 for V < 9E_R (not "q_max ≤ π/5").
- F452 (Dalibard, Cours 4): eq. (39) cos(aq) < 0 ⇔ |q| > π/(2a) has no citation next to it; Fallani 2004 and Mun 2007 are not cited there (Wu & Niu 2001, 2003 and Hilligsøe & Mølmer 2005 are cited in §2-2).
- F470 (Kwon 2015): v_c = 0.37 c_s (R ≫ ξ) is cited to Huepe & Brachet 2000, Berloff & Roberts 2000, Rica 2001, Pham, Nore & Brachet 2005 and Pinsker & Berloff 2014, not to Frisch, Pomeau & Rica 1992.
- F468 (Kwon 2015): the body gives v_c/c_s "about 0.40" for the stiffest obstacle.
- F467 (Neely 2010): the 10 µm is the Gaussian 1/e² radius of the obstacle beam.
- F477 (Singh 2017): the verbatim relaxation sentence is about the wing temperature and no relaxation after 100 ms; it does not mention a shifted critical phase-space density.
- F473 (Kwon 2016): batch 10's correction is withdrawn: the "narrow range of v above v_c" sentence is verbatim and St_∞ ∼ 0.2 is supported (inferred from N_c ≈ 4; the quoted numerics give 0.14).
- F480 (Wu & Niu 2001): |k| > √c is the Landau condition in free space; k_d = (c + 1/16)^{1/2} is obtained by substituting q = 1/2 for v ≪ 1.
- F482 (Smerzi 2002): the physics sentence now comes from the live arXiv version cond-mat/0207172; the withdrawal note of cond-mat/0207139 remains unread.
- F484 (De Sarlo 2005): the abstract does not say "first".
- F299 (Ramanathan 2011): "v_c/c_eff ≈ 0.6 … independent of c_eff" is stated in the paper (F446 verified); "no numerical v_c" is withdrawn.
- F328 / F433 (Desbuquois 2012 vs Hadzibabic–Dalibard 2011): g̃ = √(8π)a/l_z = 0.093 for the ENS stirring experiment; the review's g̃ = 0.15 is "as in the ENS experiment [27]"; refs [26]–[28] not identified.
- F326 / F506 (Hadzibabic–Dalibard 2011): a_z ≪ ξ, λ/√(2π) confirmed by two independent reads (journal PDF, arXiv PDF).
- F508 (Hadzibabic–Dalibard 2011): Eq. (76) is a₂ = a_z√κ exp(−√(π/2) a_z/a_s), κ ≈ 3.5 (verified on the arXiv PDF); the "π/2" without root of batches 11/11b was a rendering garble.
- F509 (Hadzibabic–Dalibard 2011): the verbatim subject is "It refers only to the properties of the density distribution …" (meaning unchanged).
- F521 (Petrov et al. 2000): Eq. (11) is g = (2√(2π)ħ²/m)/[l/a + (1/√(2π)) ln(1/(πq²l²))]; the paper has no explicit exponential form (exp(−√(π/2) l/a) is a rewriting); in Eq. (9) r is the relative separation and G is not called a scattering amplitude.
- F593 (Mark 2011): (U/J)_c = 34.8 (mean field) and ≈ 29.3 (QMC) are both theory values; the text says "close to"; "remarkable agreement" of measured transition points was not found.
- F552 (Clément 2009): the critical region is U/J = 8.5–9 (not 8–10); the 2Δ_ph peak is attributed to trap inhomogeneity and a not fully adiabatic loading (verbatim).
- F563 (Kollath 2006): "the peak height of the peaks at ħω ≳ 2U" is the measure of incommensurability.
- F564 (Kollath 2006): U/J ≈ 95 at V₀ = 15 E_r is from the Fig. 1 context (U ≈ 0.71 E_r, J ≈ 0.0074 E_r, δV = 0.01); δV₂ = 0.2 is the Fig. 3 strong modulation; the agreement with Stöferle et al. holds only "provided" an incommensurately filled region is assumed.
- F541 (Greiner 2002): the gap-probe sentence on arXiv:2506.21303 is "If a potential gradient is applied to the system along the z-direction, such that the energy difference between neighbouring lattice sites equals the on-site interaction energy U" (the ledger's "If now the lattice potential is tilted …" was not found again).
- F518 (Sunami 2022): η_c(L) = η_BKT/(1 + 0.5/(ln L + C)) verbatim; it predicts η_c(L) ∼ 0.21 for this system (cites Weber 1988).
- F517 (Fletcher 2015): 0.05 < g̃ < 0.5 and (ω_r, ω_z) ≈ 2π × (38, 4100) Hz are verbatim; the critical-point criterion (sharp peak in n(k)) is only a paraphrase.
- F579–F581 (Gerbier 2005a): all numbers verbatim, including the 160 ms ramp and λ_L = 850 nm; F410's "few percent at 30 E_R" is now verbatim (upgraded).
- F334 / F489 / F490 (Hadzibabic 2006): α drops from 0.5 (high T) to 0.25 on cooling, verbatim on arXiv cond-mat/0605291.
- F514 (Tung 2010): "Within each layer, approximately 6.2×10⁵ atoms feel a harmonic potential": per layer; two extractions agree; to be read by eye before quoting.
- F585 (Pollet 2010): the peak-width criterion is a proposal the paper cites ("It has been proposed …"), not its own method.
- F605 (Pollet–Prokof'ev 2012): "T/J = 0.5" is removed; the sentence ends "… and even slightly above it!" with no value.
- F601 (Gerbier 2006): the threshold 6.0(3)×10⁴ is verbatim, but not "at 40 E_r" (MI depths 20 and 40 E_r); the wording is "a Mott plateau with doubly-occupied sites", not "n = 2 plateau".
- F613 (Billy 2008): the text gives no numerical L_loc (figures only); the Fig. 3 caption says L_loc can be measured "up to about 2 mm" (4 mm disorder); "~0.3–2 mm" must not be quoted.
- F615 / F385 (Roati 2008): for β = 1.1972 the text gives the onset of localisation at Δ/J ≅ 6 and exponential localisation for Δ/J ≥ 7 ("NOT found as a number" withdrawn).
- F550 (Ernst 2010): Bragg momenta 0.64, 0.71 and 0.93 π/a with a = 515 nm; the text gives no band-gap value and no Bragg angles.
- F642 (Semeghini 2015): the measured E_c is about 20 % above self-consistent theory and about 40 % above numerics (direction confirmed; flag cleared).
- F609 (Rey 2005): the MI sentence is "its response to the Bragg perturbation is temperature dependent" (not "is sensitive to finite temperature").
- F627 (Lugan 2007b): k_max ≃ 2/(3σ_R) for σ_R ≫ ξ and k_max ≃ 1/(√2 ξ) for σ_R ≪ ξ (the "2σ_R/3" reading is withdrawn); S(kξ) = 2(kξ)²/[1+2(kξ)²]; the companion k = ξ⁻¹/√6 was not returned.
- F628 (Lugan 2007b): "We expect that the AL of BQPs could be observed directly, for instance as a broadening of the resonance lines in Bragg spectroscopy." (both "the" restored).
- F624 (Geier 2025): the Leggett bounds coincide "in the 1D case" (not "for 1D stripe disorder").
- F647 (Zhu 2023): "T ≃ 8E_r/k_B for g̃_0 = 0.05" is in the paper's Conclusion; the "suspected extraction error" note is withdrawn.
- F640 (Mendoza-Coto 2025): "isotropic non-local two-body interaction" (arXiv; "long-range" in the APS synopsis); "five gapless excitation modes".
- F586 (Spielman 2007): t/U ≈ 0.06 is cited to Elstner & Monien 1999 and Wessel et al. 2004.
- F516 (Yefsah 2011): agreement with Prokof'ev–Svistunov is only implied (via Hung et al. 2011 "showing a similar agreement").
- F645 (Gadway 2011): without impurities s_c = 6.2 ± 0.5 (impulse response) and 5.7 ± 0.5 (peak width); with impurities s_c = 3.0 ± 0.5 (transport fit); no shift for incommensurate lattices with s′ ≤ 3.
- F570 / F309 (Stenger 1999): "1 % of the single–photon recoil"; the expanded-cloud resonance broadens "from about 2 kHz to 20 kHz" ("rms width" not returned); ν₀ = 100 kHz now verbatim.
- F498 / F319 (Ville 2018): the 1.90(9) mm/s standing-wave run is in a box with L_y = 57(1) µm at T/T_c = 0.41(7); the pulse run has T/T_c = 0.37(12) and n_2D = 29(3) µm⁻².
- F560 (Endres 2012): the sentence ends "… is undoubtedly expected in these systems"; the referent (3D) is not shown.
- F559 (Endres 2012): the prefactor 3√2 − 4 is confirmed on the arXiv PDF (ar5iv loses the √).
- F467, F445, F463, F471, F436, F438, F439, F440 and the other round-2 paraphrase lines: verbatim sentences now recorded; paraphrase flags cleared (see the ledger's phase-4b paragraph).
- F343 (Chomaz 2015): "a number fluctuating between 0 and 5" is now verbatim on nature.com (upgraded to verified).
- F387 (Pasienski 2010): both abstract sentences now returned in full, including "excluding predictions of a disorder-induced or 're-entrant' superfluid" (upgraded to verified).

## Statements not confirmed (round 2)

- Steinhauer et al. 2002: μ/h = 1.91 ± 0.09 kHz; arXiv v1 and the current arXiv version give 2.02 ± 0.09 kHz; v2 and the PRL text were not read (HTTP 429); 1.91 is probably a confusion with Stöferle 2004's ratio (1.91 ± 0.04) (F311).
- Kollath et al. 2004: the regime in which the local density approximation is confirmed; the verbatim sentence has no qualifier, a fetch-tool summary adds "for weak interactions" (F584, partly verified).
- Tung et al. 2010: the atom number 6.2×10⁵ per layer (two extractions agree; not read by eye) (F514).
- Frisch, Pomeau & Rica 1992: content not read (no arXiv version, not reached in three rounds); the √(2/11) c ≈ 0.42 c criterion is known only as quoted by Raman 1999 (F455).
- Hadzibabic–Dalibard 2011: the identities of refs [26]–[28] behind "∼10⁻¹ [26, 27]", "∼10⁻² [28]" and "the ENS experiment [27]" (F328).
- Christodoulou et al. 2021: the measured first- and second-sound speeds are given in mm/s only in the figures (F494).
- Chauveau et al. 2023 and Tao et al. 2023: no numerical f_s in the text (F501, F502).
- Billy et al. 2008: L_loc values are in the figures only (F613).
- Greiner et al. 2002: the lattice-depth calibration method was not returned in two attempts (F541, F545).
- Also open: the withdrawal note of arXiv:cond-mat/0207139 (F482); Lugan 2007b k = ξ⁻¹/√6 (F627); Sanchez-Palencia 2007's 460 µm example (F629); Fallani 2008's Δ ≳ U and ξ < ζ sentences (F634); Yao 2020's T = 0.1 E_r/k_B (F639); De Sarlo 2005's q = 0.56 q_B at s = 0.2 (F487, R4 read only); Ville 2018's "no discernable discontinuity" (F499); steinhauer2003 authors; schulte2005 authors and arXiv ID; 26 round-2 lines not reached (listed in the ledger's phase-4b paragraph).

## Resolved by round 2 (earlier "could not confirm" items)

- Hadzibabic et al. 2006 exponent α (0.5 → 0.25 on cooling, verbatim); Christodoulou et al. 2021 T_c = 42(4) nK and c_B ≈ 2.3 mm/s (verbatim; sound speeds still figures only); Greiner et al. 2002 gap spectrum (resonances, U/J ≈ 36 at 13 E_r); Chomaz et al. 2015 "0 and 5"; Pasienski et al. 2010 "re-entrant" sentence; Roati et al. 2008 Δ/J thresholds (≅ 6, ≥ 7); D'Errico et al. 2014 "U = 44J" (appears with Δ = 10J; caption vs text still not stated).
