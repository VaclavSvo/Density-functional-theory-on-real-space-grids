import re, glob, collections
c = collections.Counter()
for f in glob.glob("sections/*.tex"):
    for m in re.finditer(r"\\cite[a-zA-Z]*\*?(?:\[[^]]*\])*\{([^}]*)\}", open(f).read()):
        c.update(k.strip() for k in m.group(1).split(","))
print(len(c), "keys"); print("once:", sorted(k for k in c if c[k] == 1))
