# Superfluidity of Bose–Einstein condensates in lattices, modulated potentials and two dimensions — literature map (LaTeX source)

**Status 23 September 2026, first edition.** 28 main-text pages (target 25, maximum 30), 8 figures, 6 tables,
200 cited sources, 22 open questions, 7 research directions. Author line: Václav Svoboda, Wolfgang Pauli Institute
(WPI), Vienna (name in every right header). PDF: `Superfluid_BEC_literature_map_2026-09-23.pdf`.
Scope: bosons only; no fermionic gases, graphene or electronic systems. The twisted-bilayer optical-lattice
experiment (Meng et al. 2023) appears only as the case in chapter 6 and the target in chapter 8.

## The agreed problem (phase 1, confirmed by the user)

A Bose–Einstein condensate in a periodic, modulated or disordered potential is superfluid only in part, and that
part has to be inferred from what can be measured: the interference and momentum patterns after release, the
spectrum of excitations, the response to a stirrer or to a phase twist, and the decay of coherence with distance.
The question is how the superfluid fraction, the Bogoliubov spectrum and the coherence of a weakly interacting
condensate change when the potential removes translational invariance, by a lattice, by quasi-periodic or speckle
disorder, or by squeezing the gas into two dimensions, and what each observable certifies about the phase of the
gas. (Full statement: `work/questions.md`; it opens the PDF on page i.)

**Answers to the scoping questions.** Context chapter: the experimental toolbox, for theorists. Position chapter:
yes — interference certifies coherence, not superfluidity; a response measurement does. Leggett's bound and the
Bose–Hubbard model are explained in Foundations (as explanations, not theses), at the user's request. Scope:
2D Bose gases (Dalibard/Beugnon, Hadzibabic, Chin, Cornell) and optical-lattice superfluids and their spectroscopy
(Bloch, Esslinger, Inguscio, Spielman, Steinhauer, Ketterle); disorder and quasi-periodic potentials at reduced
depth; supersolids only as the source of one f_s method. Perspective: only "where these observables meet the
twisted-bilayer problem" (chapter 8). Request during the work: "make it great, be real with research promises,
research thoroughly" → a second research round (four agents, full-text reads) and a second checking round.

## Files

| file | content |
|---|---|
| `review.tex` | preamble, macros (`\ER \LM \fs \Ds \cs \vc \gt \Rb \lead \bq`), box styles; `\input`s the sections |
| `sections/00_front.tex` | title; The problem + method box; In one page; Contents and routes |
| `sections/01_topic.tex` … `10_reading.tex` | chapters 1–10 |
| `sections/A_glossary.tex` | glossary of both fields |
| `refs.bib` | 241 entries (200 cited); `\vpartial{…}` marks what could only be partly verified; preprints as `@misc` |
| `figures/make_figures.py` | Fig. 2.2 (measured critical velocities and the f_s measurements table) and Fig. 5.1 (coverage matrix); every plotted element carries ledger ids in the script; `coverage_matrix.csv` lists the justification per cell |
| `tools/` | `build.sh` (pdflatex/bibtex/stats/two passes), `stats.py`, `pages.py`, `sheets.sh`, `fill.py`, `citeuse.py`, `guard.py`, `worddiff.sh`, `flat.py` |
| `map_flat.tex` | single-file version (project copy) |
| `facts_ledger.md` | 648 lines; every number in the map traces to one (statuses: verified 357, corrected 68, partly verified 125, unchecked 44, to check 31, computed 12, excluded 11; only verified/corrected lines are stated plainly, partly verified ones carry "as reported"/"according to", unchecked and to-check lines are not used for numbers) |
| `method_notes.md`, `corrections_list.md` | method log; corrections to the starting documents and research briefs found by the checks |

| # | chapter | file | pages |
|---|---|---|---|
| 1 | The topic in brief | 01_topic | 1–3 |
| 2 | Foundations (Landau criterion and why measured v_c < c_s; superfluid fraction and Leggett's bound explained; Bogoliubov spectrum; Bose–Hubbard model; quasi-2D and BKT) | 02_foundations | 4–7 |
| 3 | Context: the experimental toolbox, for theorists | 03_context | 8–10 |
| 4 | Data, benchmarks and verification | 04_benchmarks | 11–12 |
| 5 | State of the art (2D gases; lattice and 3D superfluids; disorder and quasi-periodic) | 05_state | 13–16 |
| 6 | Position: interference certifies coherence, not superfluidity | 06_position | 17–19 |
| 7 | Around the topic (supersolids and Josephson; flat-band bosons and photonic analogues) | 07_around | 20–21 |
| 8 | Observables for the twisted-bilayer problem | 08_perspective | 22–24 |
| 9 | Open questions (Q1–Q22, D1–D7) | 09_open | 25–27 |
| 10 | Reading paths and outlook | 10_reading | 28 |
| — | References; A Glossary | | 29–42 |

## Build

```
bash tools/build.sh                 # from this folder: pdflatex → bibtex → stats.tex → two passes; prints checks
python3 figures/make_figures.py     # regenerates the two data figures from the ledger values in the script
```
TeX Live with mathpazo, helvet, tcolorbox, tikz, natbib, doi, xurl; python3 with matplotlib.

## How it was made and what the checks found

Starting material: the project's earlier map on twisted-bilayer optical lattices (161 checked sources, 85 reused
with their statuses) and its briefing. Research: three agents (148 web calls) on the Landau criterion and critical
velocity, Bogoliubov spectra and Bragg spectroscopy, 2D gases, lattice superfluids and Bose–Hubbard observables,
disorder, and interference/coherence; then four agents (189 calls) reading full texts for the missing numbers and
adding vortex nucleation and lattice instabilities, BKT and sound theory, Bose–Hubbard spectroscopy and the
amplitude mode, and the Bose glass. Checking: 18 checkpoint files in two rounds (batches 1–9, then 10–15 with
verbatim re-reads), five and then six checker agents, each ≤ 9 minutes / 20 web calls per round; routes: arXiv/ar5iv
full texts, nature.com, publisher pages where reachable, search listings for APS volume numbers (journals.aps.org,
OpenAlex and Crossref were blocked). Result for the 200 cited sources: 69 verified or corrected in full, 131 partly
verified (in most cases the journal volume/pages were seen only in a search listing, or one clause was not found
verbatim), none unverifiable. Then a rewrite pass with the citation/number guard and word-diff, a reader review, an
internal-consistency audit, two independent fact-checks (37 findings) and a second independent fact-check after the
fixes (14 findings, all applied), and a visual QA of every page.

The most consequential corrections to the starting material and to the research briefs (full list in
`corrections_list.md`):

- Weimer et al. 2015 and Kondov et al. 2011 are fermionic and were dropped; Singh et al. 2016 simulates a molecular
  Fermi gas and was dropped.
- The quasi-2D condition is a_z ≪ ξ, λ/√(2π) (one extraction had inverted it); Eq. (76) of Hadzibabic–Dalibard reads
  a₂ = a_z √κ exp(−√(π/2) a_z/a_s), κ ≈ 3.5.
- Hadzibabic et al. 2006: the exponent α drops from 0.5 to 0.25 on cooling (the docs had the direction reversed).
- Steinhauer et al. 2002: the arXiv text gives μ/h = 2.02(9) kHz; the "1.91" in earlier notes was not found in any
  version and is probably Stöferle et al.'s ratio 1.91(4).
- Kühner–Monien 1998: (U/J)_c ≈ 3.61 (our inverse of J_c/U = 0.277(10)), not 3.3.
- The "0.37 c_s" vortex-nucleation value is cited by Kwon et al. 2015 to Huepe–Brachet, Berloff–Roberts, Rica,
  Pham et al. and Pinsker–Berloff, not to Frisch–Pomeau–Rica 1992 (whose text was not reached).
- Onofrio et al. 2000: "A drag force arises due to the pressure difference across the moving object" (not a gradient).
- Burger et al. 2001 do not name the Landau criterion; Wu and Niu 2001 suggested a dynamical instability for their
  data; Fallani et al. 2004 and Mun et al. 2007 identified instability and two-atom scattering in their own data.
- Tao et al. 2023 measured sound speeds by Bragg scattering; the agreement with Leggett's formula is BdG theory, and
  no numerical f_s is given; Chauveau et al. 2023 give no numerical f_s either; Rabec et al. 2026's f_s^(yy) = 0.82(2)
  comes from the dynamic method in the published PRL, with the static method agreeing.
- Greiner et al. 2002 (arXiv:2506.21303, posted 2025): U/J ≈ 36 at 13 E_r; "at a potential depth of around 13 E_r the
  interference maxima no longer increase in strength … at 22 E_r no interference pattern is visible at all".
- Mark et al. 2011: both 34.8 and 29.3 are theory values; Sunami et al. 2023 is Science 382, 443, not PRL; "Ozawa &
  Stringari PRL 119, 250402" was a wrong citation (that DOI is Bombin et al.); Gerbier 2005a/b/2006 are three papers.
- Numbers deliberately not used: Christodoulou 2021 sound speeds (figures only); Billy 2008 localisation lengths
  (figures only); Braun 2015 exponent range; D'Errico "U = 44J" (figure caption from exact diagonalisation).

## Rules for a later polishing pass

1. Keep numbers, units, quotations and citation attachments; re-check against `facts_ledger.md`.
2. Keep the hedges: "preprint", "as reported", "according to the paper/authors", "was (not) found for this map",
   "within Bogoliubov theory", "our remark", "our inverse", "figures only", "via BdG theory".
3. Keep theory and experiment apart (Mark 2011; Tao 2023 f_s; Kato 2008 QMC; Gautier 2021 QMC).
4. Keep the map project-neutral; chapter 8 describes observables, it does not plan the thesis.
5. After editing: `bash tools/build.sh`; 0 overfull / 0 undefined; `python3 tools/citeuse.py` (200 keys);
   `python3 tools/fill.py` on the front pages.

## Known limitations

- 131 sources are `partly verified`, mostly because APS volume/article numbers could only be read from search
  listings; each carries a `\vpartial` note in the bibliography.
- Not resolved: Steinhauer 2002's published μ/h; the range in which Kollath 2004's LDA holds; Tung 2010's
  6.2×10⁵ atoms per layer (two extractions agree, not read by eye); Frisch 1992's content; the refs [26]–[28] of
  Hadzibabic–Dalibard 2011; Greiner 2002's depth-calibration method; venues of sengupta2005, pollet2009, yao2020,
  podolsky2011, holzmann2008b, schori2004, fallani2008, lye2005 (arXiv records only).
- Gerbier 2008's "about 100 ms" far-field time is the authors' estimate; the parameters they state give ≈ 0.2 s
  (noted in the text as their estimate, not recomputed).
- No experiment measuring f_s in a disordered or moiré gas, no Bragg observation of Anderson-localised Bogoliubov
  quasiparticles, and no Higgs-mode measurement in a disordered lattice were found for this map.
