#!/bin/bash
cd "$(dirname "$0")/.." || exit 1
mkdir -p sheets && rm -f sheets/*.png && pdftoppm -r 45 -png review.pdf sheets/p
python3 - <<'PY'
import glob, subprocess
p = sorted(glob.glob("sheets/p-*.png"))
for k in range(0, len(p), 8):
    subprocess.run(["montage", *p[k:k+8], "-tile", "4x2", "-geometry", "+6+6", f"sheets/sheet{k//8}.png"])
print(len(p), "pages")
PY
