import re, glob, os, collections
CITE = r"\\cite[a-zA-Z]*\*?(?:\[[^]]*\])*\{([^}]*)\}"
def facts(t):
    t = re.sub(r"(?<!\\)%.*", "", t)
    keys = collections.Counter(k.strip() for m in re.finditer(CITE, t) for k in m.group(1).split(","))
    t = re.sub(CITE, " ", t)
    t = re.sub(r"\[[^\]]*\]", " ", t)
    t = re.sub(r"-?\d+(?:\.\d+)?\s*(?:pt|mm|cm|em|ex|bp|in)\b", " ", t)
    t = re.sub(r"\\(?:setcounter|vspace|hspace|stretch|Needspace)\*?\{[^}]*\}(?:\{[^}]*\})?", " ", t)
    nums = collections.Counter(re.findall(r"(?<![\w.])\d+(?:\.\d+)?", t))
    return keys, nums
for f in sorted(glob.glob("sections/*.tex")):
    old = os.path.join("sections_before_rewrite", os.path.basename(f))
    if not os.path.exists(old): continue
    (k0, n0), (k1, n1) = facts(open(old).read()), facts(open(f).read())
    gone = sorted(k for k in k0 if k not in k1)
    fewer = sorted(f"{k} {k0[k]}->{k1[k]}" for k in k0 if 0 < k1[k] < k0[k])
    new = sorted(k for k in k1 if k not in k0)
    lost_n, new_n = sorted((n0 - n1).elements()), sorted((n1 - n0).elements())
    if gone or fewer or new or lost_n or new_n:
        print(f"{f}\n  no longer cited: {gone}\n  cited fewer times: {fewer}\n  newly cited: {new}"
              f"\n  numbers gone: {lost_n}\n  numbers new: {new_n}")
