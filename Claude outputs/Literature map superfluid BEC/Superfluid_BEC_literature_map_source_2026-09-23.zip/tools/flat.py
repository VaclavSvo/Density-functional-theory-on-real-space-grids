import re
s = open("review.tex").read()
print(re.sub(r"\\input\{(sections/[^}]+)\}", lambda m: open(m.group(1) + ".tex").read(), s))
