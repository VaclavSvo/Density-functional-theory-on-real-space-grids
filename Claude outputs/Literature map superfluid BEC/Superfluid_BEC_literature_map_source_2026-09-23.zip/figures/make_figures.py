"""Figures for literature map 2 (bosonic superfluidity in lattices, modulated potentials and 2D).

Produces, in this directory:
  fig_measured.pdf / .png   16 x 12 cm: (a) measured v_c/c_s, (b) table of the superfluid-fraction measurements
  fig_coverage.pdf / .png   (b) coverage matrix experiment x observable
  coverage_matrix.csv       one line per non-empty cell, with the ledger ids behind it

Every number is typed as a string, exactly as stated in work/facts_ledger.md (ids in the data and comments of
this file and in the CSV; they are never drawn in a figure). Nothing is recomputed, except that the Raman 1999 and Burger 2001 points are the ratio of two speeds the
authors state (drawn with open markers and labelled with both speeds). Statuses are embedded below; if the
ledger is found at LEDGER they are cross-checked at run time and any mismatch stops the script.
Run: python3 make_figures.py  (matplotlib, Agg backend)
"""
import csv
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402
from matplotlib.patches import Rectangle  # noqa: E402
from matplotlib.font_manager import FontProperties  # noqa: E402
from matplotlib.textpath import TextToPath  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
LEDGER = os.path.join(HERE, "..", "..", "work", "facts_ledger.md")
INVENTORY = os.path.join(HERE, "..", "..", "work", "sources_inventory.md")

# ---------------------------------------------------------------- style
BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
INK, MUTED, RULE = "#0b0b0b", "#898781", "#c3c2b7"
BAND = "#f3f2ee"
CM = 1 / 2.54
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8, "axes.labelsize": 8, "xtick.labelsize": 8,
    "ytick.labelsize": 8, "axes.edgecolor": RULE, "axes.linewidth": 0.6, "xtick.color": MUTED,
    "ytick.color": MUTED, "xtick.labelcolor": INK, "ytick.labelcolor": INK, "axes.labelcolor": INK,
    "text.color": INK, "pdf.fonttype": 42, "savefig.dpi": 300,
})

# ---------------------------------------------------------------- statuses of every id used
STATUS = {
    "F010": "verified", "F011": "verified", "F015": "verified", "F023": "verified", "F116": "verified",
    "F118": "verified", "F120": "partly verified", "F161": "verified", "F162": "verified",
    "F163": "partly verified", "F164": "verified", "F165": "verified", "F181": "verified",
    "F243": "verified", "F481": "verified", "F502": "partly verified", "F265": "verified", "F267": "partly verified", "F268": "verified",
    "F270": "verified", "F271": "verified", "F272": "verified", "F273": "verified", "F291": "verified",
    "F292": "verified", "F293": "verified", "F294": "corrected", "F295": "verified", "F296": "verified",
    "F297": "verified", "F300": "verified", "F301": "verified", "F302": "verified", "F304": "verified",
    "F305": "corrected", "F306": "verified", "F307": "verified", "F310": "verified", "F311": "corrected",
    "F312": "verified", "F313": "verified", "F314": "verified", "F317": "verified", "F318": "verified", "F319": "corrected",
    "F321": "verified", "F334": "verified", "F335": "verified", "F338": "verified", "F341": "verified",
    "F342": "verified", "F346": "verified", "F347": "verified", "F350": "verified", "F351": "verified",
    "F352": "verified", "F353": "verified", "F354": "verified", "F360": "verified", "F361": "verified",
    "F363": "verified", "F369": "corrected", "F370": "verified", "F377": "verified", "F378": "verified",
    "F379": "verified", "F380": "verified", "F381": "verified", "F384": "verified", "F385": "verified",
    "F386": "partly verified", "F389": "partly verified", "F390": "verified", "F391": "verified",
    "F392": "verified", "F393": "verified", "F394": "verified", "F399": "verified", "F400": "corrected",
    # inventory rows with no ledger line (status = inventory status column)
    "inv:gerbier2005a": "partly verified", "inv:gerbier2005b": "verified",
    "inv:spielman2008": "partly verified",
}
CITABLE = {"verified", "corrected", "partly verified"}


def crosscheck():
    """Stop if an embedded status disagrees with the ledger / inventory (when those files are present)."""
    if not os.path.exists(LEDGER):
        print("ledger not found; embedded statuses used unchecked")
        return
    led = {}
    for line in open(LEDGER, encoding="utf-8"):
        if line.startswith("| F"):
            c = [x.strip() for x in line.strip().strip("|").split(" | ")]
            led[c[0]] = c[4]
    inv = {}
    if os.path.exists(INVENTORY):
        for line in open(INVENTORY, encoding="utf-8"):
            if line.startswith("| ") and not line.startswith("| key"):
                c = [x.strip() for x in line.strip().strip("|").split(" | ")]
                if len(c) > 3:
                    inv[c[0]] = c[-2]
    bad = []
    for k, v in STATUS.items():
        got = inv.get(k[4:]) if k.startswith("inv:") else led.get(k)
        if got is not None and got != v:
            bad.append((k, v, got))
        if got is None:
            bad.append((k, v, "missing"))
    if bad:
        raise SystemExit(f"status mismatch: {bad}")
    print(f"statuses cross-checked: {len(STATUS)} ids agree with ledger/inventory")


def tag(ids):
    """'verified' if at least one id is verified/corrected, 'as reported' if all are partly verified."""
    sts = [STATUS[i] for i in ids]
    assert all(s in CITABLE for s in sts), ids
    return "verified" if any(s in ("verified", "corrected") for s in sts) else "as reported"


# ================================================================ (a) fig_measured
# Layout (16 cm x 12 cm): panel a (v_c/c_s dot chart) in the top ~5.3 cm, panel b (text table of the
# superfluid-fraction measurements) below it, <= 6 cm, then one grey note line. No ledger ids and no status
# words are drawn; the ids live only in the data below. A row whose ids are all "partly verified" gets a
# dagger and the legend tag "† as reported" (none at present).
FIG_W, FIG_H = 16.0, 12.0  # cm

# v_c/c_s, one row per measurement. kind: "stated" = ratio stated by the authors (filled marker);
# "pair" = ratio of two speeds the authors state (open marker, both speeds in the label).
VC = [
    # label, system, colour, marker, kind, centre, lo, hi, annotation, ledger ids
    ("Raman 1999", "3D BEC, stirred", BLUE, "o", "pair", "0.26", None, None,
     "1.6 vs 6.2 mm/s", ["F292", "F293"]),
    ("Onofrio 2000", "3D BEC, stirred", BLUE, "o", "stated", "0.11", "0.09", "0.13",
     "0.11(2), higher density", ["F294"]),
    ("Onofrio 2000", "3D BEC, stirred", BLUE, "o", "stated", "0.07", "0.05", "0.09",
     "0.07(2), lower density", ["F294"]),
    ("Desbuquois 2012", "2D gas, stirred", ORANGE, "s", "stated", None, "0.3", "0.6",
     "range 0.3–0.6", ["F296", "F297"]),
    ("Burger 2001", "1D lattice, transport", AQUA, "D", "pair", "1.0", None, None,
     "$v_\\mathrm{max}$ 5.3(5) vs $c_\\mathrm{s,max}$ 5.2 mm/s\n(dynamical-instability reading)",
     ["F305", "F306", "F481"]),
]
XMAX = 1.06
DAGGER = " †"  # appended to rows whose ids are all "partly verified"


def mark(ids):
    return DAGGER if tag(ids) == "as reported" else ""


def panel_vc(fig):
    """Panel a. Axes geometry in cm, measured from the bottom-left corner of the figure."""
    left, width, bottom, height = 3.35, 8.05, 7.75, 3.45
    ax = fig.add_axes([left / FIG_W, bottom / FIG_H, width / FIG_W, height / FIG_H])
    n = len(VC)
    ys = list(range(n))[::-1]
    band_x0 = (0.15 - left) / width  # shaded bands start under the row labels
    for y in ys[::2]:
        ax.axhspan(y - 0.5, y + 0.5, xmin=band_x0, xmax=1.0, color=BAND, lw=0, zorder=0, clip_on=False)
    ax.axvline(1.0, color=RULE, lw=0.8, zorder=1)
    ax.text(0.985, n - 0.5, "$v_\\mathrm{c} = c_\\mathrm{s}$", ha="right", va="bottom", fontsize=7,
            color=MUTED)
    for y, (lab, sysname, col, mk, kind, c, lo, hi, ann, ids) in zip(ys, VC):
        if lo is not None:
            ax.plot([float(lo), float(hi)], [y, y], color=col, lw=2.2 if c is None else 1.1,
                    solid_capstyle="round" if c is None else "butt", zorder=2)
            if c is not None:  # stated uncertainty: small end ticks
                ax.plot([float(lo)] * 2 + [float(hi)] * 2, [y - 0.13, y + 0.13, y - 0.13, y + 0.13],
                        color=col, lw=1.1, ls="none", marker="|", ms=4.5, mew=1.0, zorder=2)
        if c is not None:
            face = col if kind == "stated" else "white"
            ax.plot(float(c), y, marker=mk, ms=5 if lo is not None else 5.5, mfc=face, mec=col, mew=1.3,
                    zorder=3, ls="none")
        ann = ann + mark(ids)
        if c is not None and float(c) > 0.75:  # Burger: annotate to the left of the marker
            ax.text(float(c) - 0.035, y, ann, ha="right", va="center", fontsize=7, linespacing=1.1)
        else:
            xa = (float(hi) if hi is not None else float(c)) + 0.025
            ax.text(xa, y, ann, ha="left", va="center", fontsize=7)
    ax.set_yticks(ys)
    ax.set_yticklabels([f"{r[0]}\n{r[1]}" for r in VC], fontsize=7, linespacing=1.1)
    ax.set_ylim(-0.5, n - 0.5 + 0.35)
    ax.set_xlim(0, XMAX)
    ax.set_xticks([0, 0.25, 0.5, 0.75, 1.0])
    ax.set_xticklabels(["0", "0.25", "0.5", "0.75", "1"], fontsize=7.5)
    ax.set_xlabel("critical velocity / sound speed, $v_\\mathrm{c}/c_\\mathrm{s}$", fontsize=7.5, labelpad=2)
    ax.tick_params(axis="x", length=2.5, pad=2)
    ax.tick_params(axis="y", length=0, pad=4)
    for s in ("top", "right", "left"):
        ax.spines[s].set_visible(False)
    handles = [
        Line2D([], [], marker="o", color=BLUE, mfc=BLUE, ls="none", ms=5, label="3D BEC, stirred"),
        Line2D([], [], color=ORANGE, lw=2.2, label="2D gas, stirred"),
        Line2D([], [], marker="D", color=AQUA, mfc="white", ls="none", ms=4.5, mew=1.2,
               label="1D lattice, transport"),
        Line2D([], [], marker="o", color=MUTED, mfc=MUTED, ls="none", ms=5, label="ratio stated by the authors"),
        Line2D([], [], marker="o", color=MUTED, mfc="white", ls="none", ms=5, mew=1.2,
               label="ratio of two stated speeds"),
    ]
    if any(mark(r[-1]) for r in VC):
        handles.append(Line2D([], [], ls="none", label="† as reported"))
    ax.legend(handles=handles, loc="center left", bbox_to_anchor=(1.03, 0.5), ncol=1, frameon=False,
              fontsize=7, handletextpad=0.5, borderaxespad=0, handlelength=1.4, labelspacing=0.55)
    fig.text(0.15 / FIG_W, 11.62 / FIG_H, "a", fontsize=8.5, fontweight="bold", va="baseline")
    fig.text(0.55 / FIG_W, 11.62 / FIG_H, "Measured critical velocities", fontsize=8.5, fontweight="bold",
             va="baseline")


# Superfluid-fraction measurements. Numeric f_s in the ledger: Rabec 2026 (0.82(2), F352) and the QMC value
# f_s ~ 0 of Gautier 2021 (F400) -> fewer than three, so the panel is a text table (no invented values).
# Ledger ids per row (not drawn): Chauveau 2023 F116 F165 F270 F350 F351; Tao 2023 F118 F271 F243 F502 (the ledger holds
# no numeric f_s); Christodoulou 2021 F321 (numbers not transcribed); Biagioni 2024 F164 F273 (abstract has no
# number); Rabec 2026 F352 F353 F354; Gautier 2021 F400.
FS = [
    # experiment, method, potential, result as stated, ledger ids
    ("Chauveau 2023",
     "sound anisotropy $c_x^2/c_y^2$; Leggett formula on the density",
     "2D $^{87}$Rb, 1D modulation, $d = 3.93(4)$ µm, $V_0 = 0$–80 nK",
     "Leggett bound exact for 1D modulation (confirmed); $f_\\mathrm{s}$ plotted, "
     "no numeric value given",
     ["F116", "F165", "F270", "F350", "F351"]),
    ("Tao 2023",
     "Bragg-measured sound speeds (anisotropic)",
     "1D lattice, $a = 266$ nm, depth up to 10 $E_\\mathrm{R}$",
     "anisotropic $f_\\mathrm{s}$ inferred from sound speeds; Leggett via BdG theory; no number",
     ["F118", "F271", "F243", "F502"]),
    ("Christodoulou 2021",
     "first and second sound",
     "2D gas across the BKT transition",
     "superfluid density consistent with BKT, including the universal jump at $T_\\mathrm{c}$",
     ["F321"]),
    ("Biagioni 2024",
     "Josephson oscillations of single supersolid cells",
     "dipolar supersolid (self-modulated density)",
     "“a relatively large sub-unity superfluid fraction”; no numeric value given",
     ["F164", "F273"]),
    ("Rabec 2026",
     "density + continuity eq. (static); compressibility + sound (dynamic)",
     "2D $^{87}$Rb, triangular lattice, $d = 6.0(1)$ µm, $V_0$ up to 4.7 $\\mu_0$",
     "$f_\\mathrm{s}^{(yy)} = 0.82(2)$ (dynamic method) at $V_0 \\simeq 2.4\\,g\\rho_0$; static method "
     "agrees; both agree with GPE and the Leggett bounds",
     ["F352", "F353", "F354"]),
    ("Gautier 2021 (QMC)",
     "path-integral QMC (winding numbers)",
     "8-fold quasicrystalline lattice",
     "Bose glass: $f_\\mathrm{s} \\approx 0$; $V_\\mathrm{c}/E_\\mathrm{R} \\simeq 1.76 \\pm 0.01$ "
     "(weak interactions); smooth compressibility crossover",
     ["F400"]),
]


_T2P = TextToPath()


def _tokens(txt):
    """Split on spaces, keeping each $...$ mathtext group in one token."""
    out, cur, inmath = [], "", False
    for ch in txt:
        if ch == "$":
            inmath = not inmath
        if ch == " " and not inmath:
            out.append(cur)
            cur = ""
        else:
            cur += ch
    out.append(cur)
    return [t for t in out if t]


def text_width(s, size, weight="normal"):
    prop = FontProperties(family="DejaVu Sans", size=size, weight=weight)
    return _T2P.get_text_width_height_descent(s, prop, ismath="$" in s)[0]


def wrap_measured(txt, width_pt, size, weight="normal"):
    """Greedy word wrap using the rendered width of DejaVu Sans at `size` pt (mathtext aware); returns lines."""
    lines, cur = [], ""
    for word in _tokens(txt):
        trial = word if not cur else cur + " " + word
        if text_width(trial, size, weight) <= width_pt or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = word
    lines.append(cur)
    return lines


TAB_FS = 7.5          # table font size, pt
TAB_LH = 8.7          # baseline-to-baseline distance, pt
TAB_PAD = 1.9         # extra vertical space per row, pt
TAB_GUTTER = 6.0      # space between columns, pt


def panel_fs(fig, top_cm, bottom_limit_cm):
    """Panel b: compact text table. Works in points in a full-width overlay axes; returns the bottom in cm."""
    PT = 72 / 2.54  # points per cm
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_axis_off()
    ax.set_xlim(0, FIG_W * PT)
    ax.set_ylim(0, FIG_H * PT)
    x0, x1 = 0.15 * PT, (FIG_W - 0.15) * PT
    edges_cm = [0.15, 2.55, 6.1, 9.6, FIG_W - 0.15]
    edges = [e * PT for e in edges_cm]
    widths = [edges[k + 1] - edges[k] - TAB_GUTTER for k in range(4)]
    y = top_cm * PT
    fig.text(0.15 / FIG_W, top_cm / FIG_H, "b", fontsize=8.5, fontweight="bold", va="baseline")
    fig.text(0.55 / FIG_W, top_cm / FIG_H, "Superfluid fraction: what was measured", fontsize=8.5,
             fontweight="bold", va="baseline")
    y -= 13.0
    for x, h in zip(edges, ["experiment", "method", "potential", "result as stated"]):
        ax.text(x, y, h, fontsize=TAB_FS, color=MUTED, va="baseline")
    y -= 3.0
    ax.plot([x0, x1], [y, y], color=RULE, lw=0.6)
    y -= 1.0
    asc = 0.76 * TAB_FS  # cap/ascender height of DejaVu Sans, pt
    for i, (exp, meth, pot, res, ids) in enumerate(FS):
        cells = [wrap_measured(exp + mark(ids), widths[0], TAB_FS, "bold")] + \
                [wrap_measured(t, w, TAB_FS) for t, w in zip((meth, pot, res), widths[1:])]
        nlines = max(len(c) for c in cells)
        h = (nlines - 1) * TAB_LH + asc + 2 * TAB_PAD + 1.6
        if i % 2 == 0:
            ax.add_patch(Rectangle((x0, y - h), x1 - x0, h, color=BAND, lw=0, zorder=0))
        for k, (x, lines) in enumerate(zip(edges, cells)):
            for j, ln in enumerate(lines):
                ax.text(x, y - TAB_PAD - asc - j * TAB_LH, ln, fontsize=TAB_FS, va="baseline",
                        fontweight="bold" if k == 0 else "normal")
        y -= h
    bottom = y / PT
    if bottom < bottom_limit_cm:
        raise SystemExit(f"table overflows: bottom at {bottom:.2f} cm < {bottom_limit_cm} cm")
    return bottom


def fig_measured():
    fig = plt.figure(figsize=(FIG_W * CM, FIG_H * CM))
    panel_vc(fig)
    tab_top = 6.45
    bottom = panel_fs(fig, tab_top, 0.5)
    print(f"fig_measured: panel b spans {tab_top + 0.22 - bottom:.2f} cm incl. its title (bottom at {bottom:.2f} cm)")
    note = "Values as stated by the cited authors; open marks are ratios of two stated speeds."
    if any(mark(r[-1]) for r in VC + FS):
        note += "  † as reported (source checked only in part)."
    fig.text(0.15 / FIG_W, 0.15 / FIG_H, note, fontsize=6.8, color=MUTED, ha="left", va="baseline")
    for ext in ("pdf", "png"):
        fig.savefig(os.path.join(HERE, f"fig_measured.{ext}"))
    plt.close(fig)


# ================================================================ (b) fig_coverage
COLS = [
    ("insitu", "in-situ density"),
    ("tof", "TOF momentum /\ninterference"),
    ("coh", "coherence g1 /\npeak width"),
    ("spec", "Bragg or modulation\nspectroscopy"),
    ("sound", "sound speed"),
    ("vc", "critical velocity /\ntransport"),
    ("fs", "superfluid\nfraction"),
    ("micro", "number statistics /\nmicroscope"),
    ("dis", "disorder or\nquasi-periodic"),
    ("q2d", "quasi-2D"),
]
F, H = "filled", "half"
# row label, preprint?, {col: (level, [ids], note)}
ROWS = [
    ("Raman 1999", False, {
        "vc": (F, ["F291", "F292"], "stirring; heating only above a critical velocity, ≈1.6 mm/s"),
        "sound": (H, ["F293"], "sound speed 6.2 mm/s at peak density stated; ledger does not say it was measured")}),
    ("Onofrio 2000", False, {
        "vc": (F, ["F294"], "critical Mach number 0.11(2) / 0.07(2)"),
        "sound": (H, ["F295"], "sound velocity 7 mm/s given with the peak density; not a sound measurement")}),
    ("Cataliotti 2001", False, {
        "vc": (F, ["F307"], "Josephson array oscillations; critical current")}),
    ("Burger 2001", False, {
        "vc": (F, ["F304", "F305"], "centre-of-mass oscillation, m*/m; dissipation onset, v_max 5.3(5) mm/s"),
        "sound": (H, ["F305"], "c_s,max ≈ 5.2 mm/s is computed, not measured")}),
    ("Greiner 2002", False, {
        "tof": (F, ["F360", "F369", "F370"], "TOF interference maxima vs lattice depth"),
        "coh": (H, ["F360", "F369"], "long-range phase coherence read from interference maxima (no g1/width stated)"),
        "spec": (H, ["F360"], "gap in the MI excitation spectrum; probe not stated in the ledger")}),
    ("Steinhauer 2002", False, {
        "spec": (F, ["F310"], "Bragg spectrum, phonon and particle regimes"),
        "sound": (F, ["F311"], "c_eff = 2.0(1) mm/s"),
        "vc": (H, ["F311"], "phonon regime gives an upper limit for v_c (Landau), not a v_c measurement")}),
    ("Stöferle 2004", False, {
        "spec": (F, ["F312", "F313"], "lattice-amplitude modulation spectra, SF continuum, MI peaks")}),
    ("Fertig 2005", False, {
        "tof": (F, ["F301"], "quasimomentum distribution after damped motion"),
        "vc": (F, ["F300", "F301"], "damped dipole transport in an axial lattice")}),
    ("Gerbier 2005", False, {
        "tof": (F, ["inv:gerbier2005a", "inv:gerbier2005b"], "interference visibility vs depth (inventory only)"),
        "coh": (F, ["inv:gerbier2005a"], "residual coherence in the Mott phase (inventory only)")}),
    ("Hadzibabic 2006", False, {
        "tof": (F, ["F334"], "matter-wave heterodyning (interference)"),
        "coh": (F, ["F334"], "loss of long-range coherence at the BKT crossover"),
        "q2d": (F, ["F334"], "BKT crossover in a trapped gas")}),
    ("Mun 2007", False, {
        "vc": (F, ["F302"], "moving lattice; currents unstable above 0.5 recoil momentum")}),
    ("Fallani 2007", False, {
        "spec": (F, ["F386"], "modulation spectra; MI resonances broaden"),
        "dis": (F, ["F386"], "bichromatic lattice 830/1076 nm")}),
    ("Spielman 2007/08", False, {
        "tof": (F, ["F377", "inv:spielman2008"], "momentum distributions; condensate fraction from TOF"),
        "coh": (H, ["inv:spielman2008"], "condensate fraction, not a coherence length (inventory only)"),
        "q2d": (F, ["F377"], "2D: vertical lattice 30(2) E_R")}),
    ("Billy 2008", False, {
        "insitu": (F, ["F384"], "density profiles: exponential vs algebraic decay"),
        "dis": (F, ["F384"], "1D speckle")}),
    ("Roati 2008", False, {
        "dis": (F, ["F385"], "1D bichromatic lattice")}),
    ("Kato 2008 (QMC)", False, {
        "tof": (H, ["F361"], "computed (QMC) interference peaks, not a measurement"),
        "fs": (H, ["F361"], "computed ρ_s vanishing above T_c, not a measurement")}),
    ("Cladé 2009", False, {
        "coh": (F, ["F335"], "coherence length longer than the thermal cloud"),
        "q2d": (F, ["F335"], "quasi-2D gas")}),
    ("Gemelke 2009", False, {
        "insitu": (F, ["F378"], "in-situ imaging, local compressibility"),
        "micro": (F, ["F378"], "suppressed density fluctuations in the MI"),
        "q2d": (F, ["F378"], "in-situ 2D imaging")}),
    ("Ernst 2010", False, {
        "spec": (F, ["F314"], "momentum-resolved Bragg spectroscopy of lattice superfluids")}),
    ("Bakr 2010", False, {
        "insitu": (F, ["F379"], "single-site in-situ imaging"),
        "micro": (F, ["F379"], "quantum-gas microscope, shells up to n = 4"),
        "q2d": (H, ["F379"], "single-plane geometry not stated in the ledger line")}),
    ("Sherson 2010", False, {
        "insitu": (F, ["F380"], "single-site in-situ imaging"),
        "micro": (F, ["F380"], "single-atom-resolved imaging; T and S from single images"),
        "q2d": (H, ["F380"], "single-plane geometry not stated in the ledger line")}),
    ("Hung 2011", False, {
        "q2d": (F, ["F338"], "2D Cs gases, scale invariance near BKT")}),
    ("Desbuquois 2012", False, {
        "vc": (F, ["F296", "F297", "F341"], "stirred obstacle; v_c 0.5–1.0 mm/s, v_c/c_s 0.3–0.6"),
        "sound": (H, ["F297"], "c_s from the formula ħ√(g̃n)/m, not measured"),
        "q2d": (F, ["F296"], "2D ⁸⁷Rb gas")}),
    ("Endres 2012", False, {
        "spec": (F, ["F317", "F318"], "amplitude-mode response to lattice modulation"),
        "q2d": (F, ["F317"], "2D SF–MI")}),
    ("Jendrzejewski 2012", False, {
        "dis": (F, ["F391"], "3D speckle")}),
    ("Zhang 2012", False, {
        "insitu": (F, ["F381"], "quantum criticality from in-situ density"),
        "q2d": (F, ["F381"], "2D lattice gas")}),
    ("D'Errico 2014", False, {
        "tof": (H, ["F389"], "momentum width implies TOF; not stated as a separate observable"),
        "coh": (F, ["F389"], "momentum width (coherence)"),
        "spec": (F, ["F389"], "modulation spectra"),
        "vc": (F, ["F389"], "transport"),
        "dis": (F, ["F389"], "1D quasi-periodic lattice")}),
    ("Chomaz 2015", False, {
        "q2d": (F, ["F342"], "uniform quasi-2D box, ν_z 350–1500 Hz")}),
    ("Semeghini 2015", False, {
        "dis": (F, ["F392"], "speckle; mobility edge")}),
    ("Meldgin 2016", False, {
        "dis": (F, ["F390"], "disorder quench, SF–BG")}),
    ("Ville 2018", False, {
        "sound": (F, ["F319"], "c = 1.49(3) mm/s in a uniform 2D box"),
        "q2d": (F, ["F319"], "uniform 2D box")}),
    ("Sbroscia 2020", False, {
        "tof": (F, ["F399"], "localisation read from TOF diffraction"),
        "dis": (F, ["F399"], "2D quasicrystalline lattice"),
        "q2d": (H, ["F399"], "2D lattice; vertical confinement not stated in the ledger")}),
    ("Christodoulou 2021", False, {
        "sound": (F, ["F321"], "first and second sound"),
        "fs": (F, ["F321"], "superfluid density from sound"),
        "q2d": (F, ["F321"], "2D BKT superfluid")}),
    ("Sunami 2022", False, {
        "tof": (F, ["F346"], "interferometric probe of two planes"),
        "coh": (F, ["F346"], "η_c = 0.17(3)"),
        "q2d": (F, ["F347"], "vertical double well, ~1 kHz per well")}),
    ("Chauveau 2023", False, {
        "insitu": (F, ["F270"], "Leggett formula on the measured density"),
        "sound": (F, ["F351"], "c_x, c_y"),
        "fs": (F, ["F116", "F351"], "f_s,x = c_x²/c_y²"),
        "q2d": (F, ["F165"], "2D ⁸⁷Rb BEC")}),
    ("Tao 2023", False, {
        "spec": (F, ["F118", "F271"], "Bragg phonons"),
        "sound": (F, ["F118", "F502"], "anisotropic sound speed from Bragg scattering"),
        "fs": (H, ["F243", "F502"], "anisotropic superfluid density inferred from Bragg-measured sound speeds; Leggett agreement is BdG theory")}),
    ("Meng 2023", False, {
        "insitu": (F, ["F023", "F265"], "in-situ 50× imaging of the moiré density"),
        "tof": (F, ["F265", "F268"], "18 ms TOF, primary and moiré peaks"),
        "coh": (H, ["F267", "F268"], "peak visibilities only; no g1 or width"),
        "spec": (H, ["F015"], "microwave spectroscopy, not Bragg or lattice modulation"),
        "q2d": (F, ["F011"], "accordion-lattice pancake")}),
    ("Yu 2024", False, {
        "tof": (F, ["F394"], "sharp peaks vs broad distribution"),
        "coh": (F, ["F363"], "Bose-glass–SF transition mapped by coherence"),
        "dis": (F, ["F363", "F393"], "8-fold quasicrystalline lattice"),
        "q2d": (F, ["F363", "F393"], "2D Bose glass, V_z = 20 E_rec")}),
    ("Biagioni 2024", False, {
        "vc": (H, ["F164"], "Josephson oscillations of supersolid cells (phase-driven flow, no v_c)"),
        "fs": (F, ["F164", "F273"], "f_s from Josephson oscillations")}),
    ("Rabec 2026", False, {
        "insitu": (F, ["F272"], "density profile (static method)"),
        "sound": (F, ["F272", "F352"], "sound velocity (dynamic method)"),
        "fs": (F, ["F352", "F354"], "f_s tensor; f_s^(yy) = 0.82(2)"),
        "q2d": (F, ["F162"], "ω_z/2π = 4.1(2) kHz, g̃ = 0.158(4)")}),
]


def fig_coverage():
    nr, nc = len(ROWS), len(COLS)
    # 16 x 14.2 cm, printed at scale 1 (\\textwidth): all type >= 7 pt.
    FW, FH = 16.0, 14.2                 # figure size, cm
    AX_L, AX_W = 3.05, 12.05            # matrix axes: left edge and width, cm
    AX_B, AX_T = 1.30, 11.95            # matrix axes: bottom and top, cm (rows + totals)
    fig = plt.figure(figsize=(FW * CM, FH * CM))
    ax = fig.add_axes([AX_L / FW, AX_B / FH, AX_W / FW, (AX_T - AX_B) / FH])
    gap = 0.35  # visual gap between observables (0..7) and potential/geometry (8..9)
    xs = [j + (gap if j >= 8 else 0) for j in range(nc)]
    ax.set_xlim(-0.6, xs[-1] + 0.6)
    ax.set_ylim(nr - 0.5, -0.5)
    ax.set_axis_off()
    MS = 5.6
    csv_rows = []
    counts = {k: [0, 0] for k, _ in COLS}
    for i, (lab, pre, cells) in enumerate(ROWS):
        if i % 2 == 0:
            ax.add_patch(Rectangle((-0.6, i - 0.5), xs[-1] + 1.2, 1, color=BAND, lw=0, zorder=0))
        rowtags = []
        for j, (key, _) in enumerate(COLS):
            x = xs[j]
            if key not in cells:
                ax.plot(x, i, marker="o", ms=1.6, color=RULE, ls="none", zorder=1)
                continue
            lvl, ids, note = cells[key]
            t = tag(ids)
            rowtags.append(t)
            if lvl == F:
                ax.plot(x, i, marker="o", ms=MS, mfc=BLUE, mec=BLUE, mew=0.8, ls="none", zorder=2)
                counts[key][0] += 1
            else:
                ax.plot(x, i, marker="o", ms=MS, fillstyle="left", mfc=BLUE, mfcalt="white", mec=BLUE,
                        mew=0.9, ls="none", zorder=2)
                counts[key][1] += 1
            csv_rows.append([lab, key, lvl, t, " ".join(ids), note])
        suffix = ""
        if pre:
            suffix += "  p"
        if rowtags and all(t == "as reported" for t in rowtags):
            suffix += " †"
        ax.text(-0.75, i, lab + suffix, ha="right", va="center", fontsize=7, color=INK)
    # column headers
    for j, (_, h) in enumerate(COLS):
        ax.text(xs[j] - 0.1, -0.75, h, rotation=50, ha="left", va="bottom", fontsize=7, color=INK,
                rotation_mode="anchor", linespacing=1.0)
    # column totals
    for j, (key, _) in enumerate(COLS):
        f, hh = counts[key]
        ax.text(xs[j], nr + 0.3, f"{f}", ha="center", va="top", fontsize=7, color=INK)
        ax.text(xs[j], nr + 1.3, f"+{hh}" if hh else "", ha="center", va="top", fontsize=7, color=MUTED)
    ax.text(-0.75, nr + 0.3, "filled", ha="right", va="top", fontsize=7, color=INK)
    ax.text(-0.75, nr + 1.3, "half", ha="right", va="top", fontsize=7, color=MUTED)
    ax.set_ylim(nr + 1.9, -0.5)
    # legend
    lax = fig.add_axes([0.03, 0.05 / FH, 0.96, 1.0 / FH])
    lax.set_axis_off()
    lax.set_xlim(0, 100)
    lax.set_ylim(0, 10)
    lax.plot(1.2, 8.3, marker="o", ms=MS, mfc=BLUE, mec=BLUE, ls="none")
    lax.text(2.8, 8.3, "measured (stated in a ledger line)", va="center", fontsize=7)
    lax.plot(35, 8.3, marker="o", ms=MS, fillstyle="left", mfc=BLUE, mfcalt="white", mec=BLUE, ls="none")
    lax.text(36.6, 8.3, "partial, indirect or computed", va="center", fontsize=7)
    lax.plot(64, 8.3, marker="o", ms=1.6, color=RULE, ls="none")
    lax.text(65.2, 8.3, "not stated", va="center", fontsize=7)
    lax.text(0.2, 3.2, "† all marks in the row rest on lines checked only in part (as reported);  "
             "p = preprint (none among these rows).\nLedger ids per cell: "
             "coverage_matrix.csv. The last two columns describe the set-up (potential, geometry).", va="center",
             fontsize=7, color=MUTED, linespacing=1.25)
    for ext in ("pdf", "png"):
        fig.savefig(os.path.join(HERE, f"fig_coverage.{ext}"))
    plt.close(fig)
    with open(os.path.join(HERE, "coverage_matrix.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["experiment", "observable", "level", "tag", "ledger_ids", "justification"])
        w.writerows(csv_rows)


if __name__ == "__main__":
    crosscheck()
    fig_measured()
    fig_coverage()
    print("wrote fig_measured.{pdf,png}, fig_coverage.{pdf,png}, coverage_matrix.csv")
