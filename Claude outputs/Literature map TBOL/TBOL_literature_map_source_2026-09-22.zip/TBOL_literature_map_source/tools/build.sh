#!/bin/bash
# usage: tools/build.sh  (from map/). pdflatex + bibtex + bbl split + stats + two more passes.
cd "$(dirname "$0")/.." || exit 1
run() { pdflatex -interaction=nonstopmode -halt-on-error review.tex > build.log 2>&1 || { echo "pdflatex failed"; grep -A3 "^!" review.log | head -20; exit 1; }; }
run; bibtex review > bibtex.log 2>&1; grep -i "warning\|error" bibtex.log | grep -v "empty year\|empty author" | head; python3 tools/splitbbl.py
run; python3 tools/stats.py 2>/dev/null | grep -v WARNING; run; run
echo "overfull: $(grep -c Overfull review.log)  undefined: $(grep -c -E '(Reference|Citation) .* undefined' review.log)  bibitems: $(grep -c '\\bibitem' review.bbl)"
grep -E "Overfull|undefined" review.log | head -20
python3 tools/pages.py
