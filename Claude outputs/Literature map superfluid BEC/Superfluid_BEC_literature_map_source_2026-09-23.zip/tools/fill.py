import glob, os, subprocess
from PIL import Image
subprocess.run(["pdftoppm", "-r", "45", "-gray", "review.pdf", "fill"], check=True)
for f in sorted(glob.glob("fill-*.pgm")):
    im = Image.open(f); w, h = im.size; px = im.load()
    top, bot = int(h * 2.4 / 29.7), int(h * (1 - 2.4 / 29.7))
    ink = [y for y in range(top, bot) if any(px[x, y] < 160 for x in range(int(w * 0.08), int(w * 0.92), 2))]
    print(f, f"{(ink[-1] - top) / (bot - top):.0%}" if ink else "empty")
    os.remove(f)
