# Method notes — map 2: superfluidity of condensates in lattices, modulated potentials and 2D

## 2026-09-23 — phase 1
- Problem statement agreed (work/questions.md). Context chapter: experimental toolbox for theorists. Position
  chapter: interference vs response measurements. Leggett's bound and the Bose–Hubbard model as explanations in
  Foundations. Scope: 2D Bose gases + optical-lattice superfluids; disorder at reduced depth; no fermions.
- Project docs skimmed: extra/thesis_topics/defence_briefing_TBOL.md (2026-09-22), the map-1 files under
  extra/tbol_literature_map/ (README, facts_ledger.md, map_flat.tex, method_notes.md), the TBOL dossier.

## Phase 2 — reading the docs
2026-09-23. No web access. Outputs: work/sources_inventory.md, work/facts_ledger.md, map/refs.bib (seed). Built by a
script (scratchpad `build_phase2.py`) from map 1's files, so reused rows, lines and bib entries are exact copies.

**Read.** Map 1 (on disk, `/home/claude/tbol_map/`): work/sources_inventory.md (157 rows), work/facts_ledger.md
(345 lines), work/verify/progress.md (final statuses, 164 keys incl. 7 Vienna bib rows), work/verify/renames.md,
map/refs.bib (164 entries), checkpoint transcripts verify/batch_3.md (tao2023, chauveau2023) for two numbers.
Project docs (project_read): extra/thesis_topics/defence_briefing_TBOL.md (2026-09-22; §3 and §4 ledgered, §1–2 and
§5–8 read for context and doc-citation cells), extra/tbol_literature_map/map_flat.tex (chapters 2, 4, 5 ledgered; the
rest read for citation cells and named classics), extra/thesis_topics/tbol_research_dossier.md (§3.2, §3.3 ledgered;
§0–§2, §3.1, §4–§7 read for context).

**Sources reused: 85** (map-1 final status: verified 7, corrected 3, partly verified 73, to check 2). 79 are on the
phase-2 brief's list; 6 were added by judgement as bosonic and in scope: li2025 (untwisted honeycomb BEC, same group
as meng2023), ding2025 (Bose-glass reentrance in twisted/quasicrystal lattices), li2024 (spin-1 BEC, twisted trilayer),
jalalimola2023 (BEC in a flat band, Bogoliubov excitations), nagao2021 and bradley2014spgpe (TWA/SPGPE methods; both
never reached by a map-1 checker, status `to check`). Group placement departs from the brief's grouping in four places:
nelson1977 and prokofev2001 under Two-dimensional Bose gases; taylor2003 under Excitations (Bogoliubov sound speed);
johnstone2024/2025 and the photonic wang2020/fu2020 under Disorder and quasi-periodic potentials. stimming2010 had no
map-1 inventory row (bib-only, batch 11); its row was built from the bib entry and progress.md.

**Excluded: 79** map-1 sources — electronic/graphene/TBG superconductivity, FQAH and fermionic quantum geometry 33
(incl. salamon2020 and yang2026, fermionic TBOL); orso2024 1 (unitary Fermi gas; Fermi-gas caveat only); lukin2023 1
(not verifiable); companies, programmes, prizes, group page 9; codes and code papers 14; ML 7; magnetic moiré 1;
atomtronics review 1; photonic devices/reviews 5; polariton condensate 1 (driven-dissipative); Vienna numerical-analysis
papers 6. Reasons per key in the inventory's "Excluded" table.

**New unchecked rows: 6.** Classics the docs name without a reference: gross1961 and pitaevskii1961 (the GPE, named in
BR, MF, D), bogoliubov1947 (BR §4 "Bogoliubov spectrum", MF, D §3.1), berezinskii1971 and kosterlitz1973 (MF ch9 Q15
"Berezinskii–Kosterlitz–Thouless", D §3.3, §5.2). One lead from map 1's working ledger (not a doc): kramer2003 (M1-F323,
search did not return it). Bibliographic data of all six are from memory and flagged "to verify"; no bib entries were
written (TODO stub line in refs.bib). Not added because no doc names them: Landau criterion, Pitaevskii–Stringari book,
Bloch–Dalibard–Zwerger RMP 2008, Hadzibabic–Dalibard 2011, Greiner et al. 2002, Jaksch et al. 1998, Fisher et al. 1989
(the docs use "Bose–Hubbard model", "Bose glass", "Mott insulator" without author or paper); Anderson localisation is
named only in work/questions.md. Named but left out as off-scope: Kibble–Zurek, Hofstadter, Hoshen–Kopelman, Gutzwiller.

**Ledger: 290 lines.** 212 carried from map 1 (verified 88, corrected 20, partly verified 71, unchecked 21, to check 3,
computed 8, excluded 1), ids renumbered F001–F212 with the map-1 id in `origin`. 78 new (briefing 39, map_flat 37,
dossier 2): verified 19, corrected 8, partly verified 14, unchecked 26, to check 1, computed 4, excluded 6. Total by
status: verified 107, corrected 28, partly verified 85, unchecked 47, to check 4, computed 12, excluded 7. Not carried:
133 map-1 lines — 59 with no source key (58 project-internal "—" lines: feasibility-code numbers, gates, plans; 1 news
release) and 74 resting only on excluded sources. Seven carried lines name an excluded key next to a reused one (M1-F095
verma2021, F096 yang2026, F133 orso2024, F262 yang2026, F297 itp2026santos, F304 uibk2023quanta, F313
pollet_worm_github); flagged "mixed keys" in `origin`.

**Deviation from the reuse rule, flagged.** Two new lines take `verified` from map-1 checkpoint transcripts, not from
ledger lines: Tao et al. numbers (266 nm, ≤ 10 E_R, ξ = 170(20) nm, N ≈ 2 × 10⁵; map 1: verify/batch_3.md#tao2023) and
the Chauveau 80 nK amplitude (map 1: verify/batch_3.md#chauveau2023).

**Inconsistencies found.**
1. BR §4 says the 2-D Leggett brackets are "tight for square potentials": the wording map 1 corrected (M1-F132; the
   paper says "The bracketing is tighter for a 2D optical potential than for a grid of columns"). Ledgered as
   `corrected` with "was: …". The map-1 inventory claims cells of perezcruz2025/2026 still carry the docs' wording
   ("heuristic" f⁻, "square lattices tightest"); a MAP 2 caveat was appended.
2. Three attributions of f_s = m/m* for a Bloch condensate: D §3.2 cites Blakie 2024 and Orso–Stringari 2024 (a
   unitary Fermi gas, excluded); MF ch2 calls it the map's own combination of Taylor–Zaremba with the sound relation;
   BR §4 says the same and "our step". Ledgered `unchecked`; orso2024 must not be cited.
3. MF ch2/ch4 cite perezcruz2025 for the phase-twist formula E(v) = E(0) + f_s N m v²/2; map 1 checked the formula only
   as the docs' Leggett definition (M1-F130, leggett1998, partly verified). Attribution unchecked.
4. D §3.3 calls Underwood–Blakie "two-component"; it is spin-1 (M1-F150, M1-F306). D §3.2 calls f⁻ "heuristic"
   (corrected, M1-F131). D §3.1 identifies the condensate metric with the minimal metric (corrected, M1-F108).
5. D §3.3 "Nagao et al. 2021/2024" is two papers; nagao2021 is a candidate identity never checked.
6. D §5.3 gives the Johnstone tunnelling range reversed and as J_M (noted in M1-F076); BR §5 and MF have it right.
7. BR §3 gives the paths and thresholds consistently with the verified lines; its readings "moiré peaks vanish first"
   and "critical depth depends on Ω_R" are interpretations (unchecked).
8. The group "Interference and coherence observables" has no source: every TOF/visibility claim in the docs rests on
   meng2023. Research agents must supply the classic visibility/coherence references.
9. Supersolid sources (biagioni2024, blakie2024, sindik2024) are kept only as f_s-method sources, per the scope.
10. luo2021 is reused for its single-particle honeycomb bands only; its Larkin–Ovchinnikov superfluid is fermionic.

## Phase 3 — searches run
- 2026-09-23. Three research agents, WebSearch/WebFetch only, rules in work/research/COMMON_RULES.md; every call is in
  **work/search_log.md**. R1 (Landau criterion, critical velocity, Bogoliubov/Bragg spectroscopy, gapped and localised
  excitations): 50 calls. R2 (quasi-2D gases, superfluid fraction, interference/coherence observables): 50 calls (budget
  reached). R3 (Bose–Hubbard and lattice superfluids, disorder and quasi-periodic potentials, in-situ observables): 48 calls.
- Routes: ar5iv.labs.arxiv.org/html/ID gave title, authors and body; arxiv.org/abs gave abstracts without metadata;
  nature.com pages worked; journal PDFs on group pages (physics.umd.edu, UT Austin, cpht.polytechnique.fr, zh.phy.cam.ac.uk,
  college-de-france.fr) worked. Failed: export.arxiv.org (robots.txt), osti.gov (robots), lmm.jussieu.fr (SSL), one CdF
  URL (404). journals.aps.org, OpenAlex, Crossref not called. No 403/429 met.
- Merge (phase 3 → 4): 102 new inventory rows (193 in scope: 85 reused, 6 phase-2 classics `unchecked`, 102 `to check`),
  new group "Interference and coherence observables" (16 rows) and subgroup "Landau criterion and critical velocity" (9);
  13 agent rows merged into reused keys + perezcruz2025 by arXiv ID; 4 cross-agent duplicates merged; 117 ledger lines
  F291–F407 (113 agent lines + 4 merge lines; 115 `to check`, 2 `excluded`); refs.bib 193 entries.
- Main finds: the critical-velocity record (raman1999, onofrio2000, desbuquois2012 v_c/c_s = 0.3–0.6); lattice transport
  and its disputed Landau reading (burger2001 vs fallani2004); Bragg spectroscopy of the Bogoliubov spectrum (stenger1999,
  steinhauer2002) and its limits in lattices (stoferle2004, du2010, ernst2010); the Higgs mode (endres2012); 2-D sound and
  superfluid density (ville2018, christodoulou2021); quasi-condensate ≠ superfluid (clade2009) and TOF caveats (kato2008,
  gerbier2008); BKT by interferometry (hadzibabic2006, sunami2022 η_c = 0.17(3)); Bose–Hubbard critical points (3D
  29.34(2), 2D 0.05974(3), 1D 3.61); quasicrystal localisation 1.78(2) E_rec vs QMC 1.76 (sbroscia2020, gautier2021).
- Corrections to the brief: Weimer et al. PRL 114, 095301 is a fermionic BEC–BCS paper (excluded); Kondov 2011 is a
  ⁴⁰K Fermi gas (excluded); Hung PRL 104, 160403 is "Slow mass transport …", not compressibility (gemelke2009 is the
  compressibility paper); Ciardi et al. is PRA 105, L011301 (2022), not "PRL 2023"; Kühner–Monien give (U/t)_c ≈ 3.61,
  not 3.3; Hadzibabic–Dalibard g̃ ≈ 0.15 (brief 0.13); Rabec f_s^(yy) = 0.82(2) is on the published PDF (map 1's "not
  found" superseded, F163 → F352).
- Not found or left open: PRA 114, 023312 ↔ arXiv:2605.06171 for guimaraes2026 (identity unconfirmed); author lists of
  PRA 79, 043623 (fabbri2009), arXiv:1101.4781 (gaul2011), PRR 7, 013187 (x2407_17558), arXiv:2210.15526 (zhu2023); no
  Bragg experiment on a disordered/Bose-glass BEC; Greiner 2002's ~13 E_r only as quoted by Zwerger; Hadzibabic 2006
  exponents; Landau 1941 cited through leggett1999/pitaevskii2016; Perrin 2026 (arXiv:2609.17097) seen only on an aggregator.
  Not fetched (budget): Leggett 1970/1998, Hagley 1999, Gerbier 2005 ×2, Kollath 2004, Pollet 2010, bloch2008, dutta2015.
- Batches for phase 4: work/verify/batches.md (6 topic batches of 16–22 + batch 7 "numbers to complete on reused sources").

## Phase 4 — checking
- 2026-09-23. 9 rounds: batches 1–7 (6 topic batches of 16–22 sources + batch 7, numbers to complete on 8 reused sources) and two
  second passes (batch 8 on the leftovers of batches 3–6, batch 9 on the final leftovers). Checkpoints: work/verify/batch_1.md …
  batch_7.md, batch_8_secondpass.md, batch_9_leftovers.md; rules in verify/CHECKER_PROMPT.md. 5 checker agents, WebSearch/WebFetch
  only, each round capped at 9 min and 20 web calls; 178 calls in total (batches 2 and 9: 19; the others 20).
- Routes that worked: ar5iv.labs.arxiv.org/html/ID (main route; no journal-ref line, so venues stay unconfirmed); arxiv.org/html/IDv1
  (native HTML: perrin2026, song2026, greiner2002's arXiv:2506.21303); arxiv.org/abs (abstract, sometimes empty); arxiv.org/pdf;
  nature.com; group copies of journal PDFs (physics.umd.edu, utexas, cpht.polytechnique.fr, zh.phy.cam.ac.uk, college-de-france.fr);
  repository.cam.ac.uk; nist.gov; WebSearch listings (bibliographic data only).
- Refused or empty: export.arxiv.org (robots; once a proxy 403 for URL length), osti.gov (robots), link.springer.com 429 and
  nature.com 429 once each (both cleared later), science.org 403; ar5iv 302 redirects to abs for six IDs. journals.aps.org,
  OpenAlex, Crossref, SciPost, PubMed, ADS never called. No source left at retry.
- Merge rule: a later checkpoint overrides an earlier one only where it upgrades; a line or source confirmed only in part or only
  on a listing is `partly verified`; checkers counted an ar5iv read as a primary record, so "verified" sources may keep a venue
  from the phase-3 listing (noted per entry in refs.bib).
- Sources (193): 46 verified, 9 corrected, 138 partly verified, 0 not verifiable, 0 retry. Checked in map 2: 118 (40 / 6 / 72);
  the other 75 reused rows keep their map-1 status. Renames: bradley2014spgpe → rooney2014, x2407_17558 → geier2025.
- Ledger (407 lines): 206 verified, 38 corrected, 93 partly verified, 0 not verifiable, 44 unchecked, 5 to check, 12 computed, 9 excluded.
- refs.bib: 193 entries, parses (bibtexparser 2.0.1); unsrtnat dry run (/tmp/bibtest3): 193 \bibitem, 0 BibTeX warnings, no LaTeX
  errors. Details: verify/progress.md (status, rounds, notes, renames), corrections_list.md (README seed).

## Phase 3b — deep research round 2
- 2026-09-23. Four agents, WebSearch/WebFetch only, rules in work/research/COMMON_RULES.md ("Round 2 addendum": numbers from the full
  text, with the sentence); every call is in **work/search_log.md** ("Phase 3b"). R4 (Landau criterion and its limits, vortex nucleation,
  drag, lattice instabilities): 48 calls. R5 (2D gases, BKT, sound, f_s): 41. R6 (Bose–Hubbard observables, Bragg, amplitude mode): 50.
  R7 (disorder, Anderson localisation, Bose glass): 50. Routes: ar5iv/arxiv.org pdf and html (full text), nature.com, group PDFs, repository
  records; refused: iopscience, osti.gov, weizmann.ac.il, web3.arxiv.org once (robots); 429 once each on arXiv 2511.04575 and
  cond-mat/0111438v2 and on nature.com nphys1799 (not retried).
- Merge: 48 new inventory rows `to check` (241 in scope; Landau subgroup +12, 2D gases +9, Bose–Hubbard +4, Excitations +6, Disorder +16,
  superfluid fraction +1); singh2016 dropped (⁶Li₂ molecular BEC tied to the excluded weimer2015); mendozacoto2025 kept, marked peripheral.
  Ledger F420–F648 (229 lines: 227 `to check`, 2 `excluded`; 27 paraphrase lines and 12 flagged extractions marked for a verbatim
  re-read). refs.bib 241 entries (48 new, 15 corrected). Batches 10–12 (18, 22, 22 sources: 48 new + 14 re-opened).
- Main finds: Landau v_c = c vs measured 0.07–0.6 c, with the reasons quoted (local sound at the edge, vortex nucleation for obstacles
  ≫ ξ, 3D geometry: winiecki1999 0.45 c, kwon2015 0.37 c_s for R ≫ ξ, jackson2000 0.13–0.20 c_s); energetic vs dynamical instability
  (wu2001, desarlo2005 q = 0.56 q_B, τ_EI = 416(55) ms); 2D numbers (christodoulou2021 g̃ = 0.64(3), T_c = 42(4) nK, D_s 0 → 4;
  hadzibabic2006 α 0.5 → 0.25; ozawa2014 sound jumps; holzmann2008 T_KT ≃ 0.70 T⁰_BEC); Greiner 2002 gap spectrum; Higgs-mode chain
  (huber2007, bissbort2011, endres2012, pollet2012, podolsky2011); the 5.83 chain (vanoosten2001, sengupta2005); disordered BH
  (pollet2009, gurarie2009, soyler2011); 1D quasi-periodic BG (yao2020 V_c ≃ 1.38 E_r); geier2025 m c² = f_s/(nκ).
- Corrections (corrections_list.md): PRL 119, 250402 is Bombin et al. (ozawa2014 = arXiv:1310.3654, venue from memory); Sunami 2023 is
  Science; gerbier2006 is a third Gerbier paper; F326 is a_z ≪ ξ, λ/√(2π); F328 g̃ = 0.093 (Desbuquois) vs 0.15 (review); F299
  v_c/c_eff ≈ 0.6; F294 "drag force"; "0.37 c" → kwon2015; Steinhauer 1.91 in no version (likely Stöferle's 1.91(4)); "U = 44J" only in
  a caption (pasienski2010 U/t = 44); T = 0.37 T_c is Ville 2018; Tao is BdG vs Leggett; IDs/venues for gaul2011, zhu2023, ota2018a, hung2011.
- Not reached: frisch1992 text (the "0.37 c" origin stays unconfirmed); leggett1999; smerzi2002 content (arXiv withdrawn); schulte2005
  (no arXiv ID); steinhauer2003 authors/text; rabec2026 and trotzky2010 (429); bloch2008 §IV; Steinhauer 2002 v2/PRL μ/h; measured sound
  speeds of christodoulou2021 (figures only); no Bragg spectrum of a disordered BEC and no 2014–2026 BG excitation-spectrum experiment.

## Phase 4b — checking round 2
- 2026-09-23. Nine checkpoints: batch_10/10b (Landau criterion, R4), 11/11b (2D gases, Bose–Hubbard observables, R5–R6), 12/12b (excitations,
  disorder, R6–R7), 13 and 14 (verbatim re-reads of round-2 lines on already-checked sources), 15 (hadzibabic2011 Eq. (76) + 24 venue listings).
  WebSearch/WebFetch only, 20 calls and 9 min per round; 178 calls (10b: 18). Rules as phase 4 (verify/CHECKER_PROMPT.md).
- Routes: ar5iv and arxiv.org/pdf (main; no journal-ref, so APS venues rest on DOI URLs in search listings); nature.com; group PDFs (umd, utexas,
  cpht, zh.phy.cam.ac.uk, phys.ens.psl.eu); ORA (ox.ac.uk) and DOAJ for publisher metadata. Failures: pure.mpg.de 403; arxiv.org/html and
  /pdf cond-mat/0111438v2 429 (twice); ar5iv 302 → abs for 0908.1182; ar5iv cond-mat/0011108 empty. No APS/Crossref/OpenAlex page opened.
- Merge rule: a later status only if it upgrades; verified sources keep `verified` when a checker downgrades for a venue not on the page or for a
  correction to a round-2 ledger line; navon2021 verified by combining rounds 11 (nature.com) and 13 (ar5iv); frisch1992 (never reached) partly verified.
- Sources (241): 66 verified, 9 corrected, 166 partly verified, 0 to check. New 48: 7 verified, 41 partly verified; 13 old rows upgraded to verified,
  kollath2006 to corrected. Ledger (648): 357 verified, 68 corrected, 125 partly verified, 44 unchecked, 31 to check (26 round-2 lines not reached),
  12 computed, 11 excluded; all 39 paraphrase/extraction flags resolved or narrowed (F514, F517, F529).
- refs.bib: 241 entries, 39 bibliographic updates; \vpartial on every partly verified entry, none on verified; bibtexparser 2.0.1 parses (0 failed
  blocks); unsrtnat dry run (/tmp/bibtest5): 241 \bibitem, 0 BibTeX warnings, 0 LaTeX errors. Open items: corrections_list.md, "Statements not confirmed (round 2)".
