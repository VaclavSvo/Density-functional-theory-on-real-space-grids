# Corrections made by the checks (phase 4, 2026-09-21)

Seed for the README. One line per correction to the Project docs' bibliographic data or claims. Sources: `verify/batch_1.md` … `batch_9.md`, `verify/batch_10_secondpass.md`. Keys are the final keys (`verify/renames.md`).

## Bibliographic corrections

- anon2025honeycomb → li2025: Y. Li, W. Han, Z. Meng, W. Yang, C. Chin, J. Zhang, "Observation of quantized vortex in atomic Bose–Einstein condensate at Dirac point with emergent spin–orbit coupling", Nat. Photon. 19, 1264–1269 (2025).
- fan2025: four authors (Z. Fan, M. Wang, J. Wang, Y. Li), not three; the arXiv title changes between versions ("ultracold atoms" → "ultracold Bose gases").
- zeng2025: arXiv versions carry two titles ("Interaction induced moiré systems …", "Dynamical Moiré Systems …"); the published title and DOI were not confirmed.
- li2024: authors and title found (T.-T. Li, Z.-H. Guo, X.-N. Wang, Q. Zhu); the lattice is a trilayer, not a bilayer.
- gonzaleztudela2019: arXiv title writes "twisted bilayer" without the hyphen.
- cheng2026, johnstone2025, wen2021, kariyado2019: titles and full author lists added (cheng2026 DOI 10.1103/ppvl-5lmg; kariyado2019 "Flat band in twisted bilayer Bravais lattices").
- Titles added where the docs gave none: julku2021a, peotta2015 (+ DOI 10.1038/ncomms9944), torma2022, huhtinen2022, zhang2025a, burgher2026 (+ authors), tanaka2025 (+ 19 authors), chauveau2023, tao2023, perezcruz2025, biagioni2024, bistritzer2011, cai2023, yoo2019, watson2023, schweigler2017, mennemann2021, kasper2020, sui2025, salamon2020, blakie2008, egorov2013, denis2025, wang2020, fu2020, mao2021, gross2017, amico2022, mellado2025, raissi2019, kovacs2022.
- julku2021b: full title "Excitations of a Bose-Einstein condensate and the quantum geometry of a flat band"; erratum is PRB 107, 019901 (2023).
- julku2023: second author is G. (Grazia) Salerno, not M. Salerno; arXiv title spells "Supefluidity".
- zenesini2024: published title "False vacuum decay via bubble formation in ferromagnetic superfluids" (no "Observation of"); pages 558–563.
- guo2025: published online 22 Jan 2025, not 2024.
- anon2025tmote2hidden → wang2025b: Yiping Wang … X.-Y. Zhu, Nature 641, 1149–1155 (2025).
- anon2026natmat → li2026: T. Li, J. Liu, J. Xie, X. Lu; a Perspective, not a review.
- verma2026: a Perspective, not a review.
- anon2025tessellation → park2025: D. Park et al., Nature 641, 896–903 (2025), twisted trilayer graphene.
- liu2023, fang2025, tu2025a, tu2025b: identified (Chaos Solitons Fractals 174, 113869; 195, 116314; 190; Physica A 666); anon2025chaos is a duplicate of fang2025.
- anon2025qfrontiers → wang2025qf: Wang et al., Quantum Frontiers 4, 9 (2025).
- taie2015 (Sci. Adv. 1, e1500854) and jo2012 (PRL 108, 045305): venues and arXiv IDs found.
- leung2020, moller2025, walkling2026, dziarmaga2023 (Jakub M. Mazur), guimaraes2026, xie2020, underwood2025: first names / full author lists added.
- banerjee2025 (Nature 638, 93–98), karnatak2025 (pages 44–45), tian2023 (Nature 614, 440; a published comment exists, arXiv:2303.06054): volumes and pages found.
- anon2023qgsf → peotta2023 (Peotta, Huhtinen, Törmä); anon2025cscr3sb5 → wu2025 (Nat. Commun. 16, 1375); anon2023topbogo → jalalimola2023.
- taylorzaremba_nd → taylor2003; leggett_nd → leggett1970 (PRL 25, 1543) + leggett1998 (J. Stat. Phys. 93, 927); zwerger_nd → zwerger2003 (J. Opt. B 5, S9); nelsonkosterlitz_nd → nelson1977 (PRL 39, 1201).
- polkovnikov2010: Ann. Phys. 325, 1790 (2010), arXiv:0905.3384 (= dossier ID x0905.3384); mertes2007: PRL 99, 190402.
- sinatra2002: the venue J. Phys. B 35, 3599 is not confirmed.
- anon2024moirebeyondvdw → natmat2024editorial (an unsigned editorial, Nat. Mater. 23, 1151); anon2023moirephotonics → du2023; anon2026npjmeta → zhang2026npj.
- anon2025sciadv: title is "Exciton polariton condensation in a perovskite moiré flat band at room temperature" (not "Room-temperature exciton-polariton condensation …").
- kovacs2022: title "Conditional physics informed neural networks" (micromagnetics, not GPE).
- anon2024gpecqed → fioroni2024 (TorchGPE); anon2025qutarang → rawat2025 (CPC 315, 109725).
- schloss2018: JOSS 3(32), not 3(30).
- tenpy_github: v1.1.0 is dated 11 Nov 2025, not 2023; licence now Apache-2.0.
- pollet_worm_github: the GitHub About line is "Worm Algorithm for Bose-Hubbard and XXZ models" (the inventory had README text).
- generalizedgpe_jl (MIT), itensors_github (Apache-2.0), wannier90 (LGPL-2.1, v3.1.0), fouriergpe_jl ("no longer actively maintained"): licence and version data filled in.
- planqc2024: page title ends "… for LRZ"; kavli2026: cite the official kavliprize.org page, not the ACerS article; umd2021rqs: dated 2 Sep 2021.

## Claim and wording corrections

- F048 (Paul et al.): clusterisation threshold is 0.03 t⊥ for commensurate and 0.06 t⊥ for incommensurate angles; the paper says "mobility islands", not "pockets" (F051).
- F069/F228 (Wang–Gao–Shi): the V_m(r) derivation is for the 3-D quasi-moiré crystal and is valid for θ·l_ho⁻¹ ≪ 1; "Ω ≪ band gap" is not in the paper.
- F071 (Wan–Gao–Shi): the large-detuning limit maps exactly onto Hofstadter's original model plus a long-range hopping term.
- F012 (Meng): the paper writes "ω_z ≈ 2π × 1 kHz"; the quoted "optimised at 1 kHz" was not found.
- F108/F109/F110/F111/F113 (Huhtinen et al. 2026a): formula is D₁ + D₂^ndeg = (2Un₀²/M)ℳ^D(k_c) with the "condensate quantum metric" (not the minimal metric); the fluctuation term D₃′ turns negative around U ≈ 0.13t; exact sentence "There can therefore be no superfluidity in a single flat band at a TRIM where the Bloch state has uniform densities."; "≥ 3 bands" holds "within Bogoliubov theory"; the quote is "flat-band superfluidity is much more difficult to achieve than flat-band superconductivity".
- F117 (Törmä–Peotta–Bernevig): the docs' quotation splices two sentences.
- F118 (Y.-C. Zhang): a two-band BEC, not a "two-component continuum flat band".
- F131/F132 (Pérez-Cruz et al. 2025): the lower bound f⁻ is explicit, not "heuristic"; the paper says "The bracketing is tighter for a 2D optical potential than for a grid of columns" (no superlattice statement).
- F139: the 2026 triangular-lattice experiment is from the Dalibard/Beugnon group, so three groups, not four.
- F150/F306 (Underwood & Blakie): a spin-1 SPGPE, not two-component; first author Andrew P. C. Underwood, not "E. Underwood".
- F157 (Lühmann): 0.0596(4) is extrapolated to an infinite lattice from clusters up to 4×4, not the 4×4 result.
- F159 (Guimaraes & Sanchez-Palencia): bands match tight binding for V₀ ≳ 5 E_r; at 15 E_r Bose–Hubbard "fails to describe but the first Mott lobe"; "V₀ ≲ 6 E_r unreliable" is not stated.
- F253 (Blakie 2024): nonclassical translational (not rotational) inertia.
- F265 (Cao et al. 2018a): "twist angles of about 1.1°"; "a carrier density of about 10¹¹ per square centimetre" ("record-low" not seen).
- F281, F283: the Nat. Mater. 2026 and Nat. Rev. Phys. 2026 items are Perspectives.
- F285: Kavli Prize 2026 confirmed on kavliprize.org (Andrei, Jarillo-Herrero, MacDonald, "for foundational work that established the field of Twistronics").
- F292 (NSF): $28–37 M over five years is the range per institute; no RQS amount is stated.
- F330 (TeNPy): v1.1.0 released 11 Nov 2025.
- F341 (GPUE): JOSS 3(32); "performance greater than other available suites" is not on the landing page.
- F073 (Kariyado–Vishwanath): rewritten as a paraphrase; the quoted sentence is not in the paper.
- F288: published title corrected (see above).

## Misattributions

- orso2024: a unitary Fermi gas at T = 0 (BdG), not a Bose-gas GP result; do not cite it for f_s = m/m* (F133, F254, F333).
- underwood2025: spin-1, not two-component; the docs' "E. Underwood" is wrong.
- perezcruz2025: by Pérez-Cruz, Astrakharchik and Massignan, not by Fattori (Fattori is a co-author of biagioni2024) (F302).
- lukin2023: no Lukin–Sotnikov–Kruchkov 2023 paper on flat-band bosons was found in two searches; the citation may be misattributed (status `not verifiable`).
- schaffer2024: micromagnetic energy minimisation, not GPE (the docs' "constrained PINNs from Vienna").
- salamon2020: the "twistronics without a twist" proposal uses fermionic atoms (e.g. strontium).
- han2025: rhombohedral graphene "without moiré superlattice effects", so not a moiré example.
- x0710.2703 is Capogrosso-Sansone et al. (2-D QMC), not Blakie; x0901.0420 is Jordan, Orús, Vidal (iPEPS), not Nagao.
- Denis & Carleo is arXiv:2404.07869; 2404.18594 is Nagao & Yunoki (found in phase 3, kept).
- anon2025tmote2hidden: last author X.-Y. Zhu, so "Xu group, UW" is not the right attribution.
- itp2026santos: the Santos group page does not support "interaction-induced moiré" (F297); zeng2025 is not a Santos paper.

## Statements the checks could not confirm

- Huhtinen et al.: the docs' quotation "There can be no superfluidity … at a time-reversal-invariant momentum" (the paper's sentence differs; see above).
- Kariyado–Vishwanath: "uniform coupling cannot produce this confining effect" (not found in the full text).
- Rabec et al.: f_s^(yy) = 0.82(2) at V₀ ≈ 2.4 gρ₀ (not in the arXiv version read; the journal ref and DOI were not re-checked).
- Chauveau, Tao, Biagioni: no numeric f_s in the text read (figures only, or "relatively large sub-unity").
- Sui et al.: the critical-coupling range 0.09–0.15 E_r (the paper gives 0.11 E_r at θ ≈ 4.4°).
- Braun et al.: the 0.3–0.6 exponent range (summary paraphrase only).
- Meng et al.: the Extended Data Fig. 4c anchor points (F031; not in the arXiv PDF); RAP preparation (F002).
- Julku–Bruun–Törmä PRB: arXiv ID not found (2104.14257 is the PRL); F103–F105 not checked.
- planqc2024 and quantA (uibk2023quanta): statements are recorded "according to the page" (company or institution), not independently confirmed.
- Also not confirmed: peotta2015 "D_s ∝ Δ∫g" and the F127 quotation; julku2023 kagome maximum near 3t; huber2010 "stiffness ∝ U"; egorov2013 a₁₁ = 100.40 a₀; underwood2025 numerical parameters; sadoune2022 CPU-hour estimate.
