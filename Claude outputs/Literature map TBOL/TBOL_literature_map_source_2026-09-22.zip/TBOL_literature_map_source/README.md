# Condensates in twisted-bilayer optical lattices — literature map (LaTeX source)

**Status 22 September 2026, first edition.** 28 main-text pages (target 25, maximum 30), 8 figures, 6 tables,
161 cited sources (147 in the main list + 14 in the group "Research connected with the WPI and Vienna"),
22 open questions, 7 research directions. Author line: Václav Svoboda, Wolfgang Pauli Institute (WPI), Vienna.
PDF: `TBOL_literature_map_2026-09-22.pdf`. The map describes the field; it does not describe the solver project.

## The agreed problem (phase 1, confirmed by the user)

Twisted-bilayer optical lattices bring moiré physics into a Bose gas. In the one experiment realised so far
(Meng et al., Nature 2023), two spin states of ⁸⁷Rb sit in square lattices rotated by 5.21° and a microwave field
couples them, in the role that interlayer tunnelling plays in twisted bilayer graphene. The experiment reports a
moiré density pattern, two distinct superfluid regimes and a superfluid–insulator transition that shifts with the
coupling. The question is how the superfluidity of a weakly interacting condensate evolves as the lowest band of
such a lattice flattens. (Full statement: `work/questions.md`; it opens the PDF on page i.)

**Answers to the scoping questions.** Context chapter: electronic moiré and quantum geometry, for Bose-gas
physicists and applied mathematicians. Position chapter: yes, both theses (1: geometric superfluidity is excluded
for uniform-Ω square TBOL, the pocket crossover is the open problem; 2, working hypothesis: SF-II is a Josephson
array of AA pockets, with four falsifiers). Perspective: platforms and groups, open codes, compute, programmes and
funding, plus flat-band / quantum-geometric superconductivity research and industry use. Own feasibility results:
included as `[computed for this map]`, reproduced from `figures/grid.csv` by `figures/make_figures.py`.
Requested later: the author's name in every right header; a group of the Vienna/WPI-connected papers (especially
Exl, Stimming, Mauser, Mazets) at the end of the references.

## Files

| file | content |
|---|---|
| `review.tex` | preamble, colours, macros (`\ER \LM \fs \Ds \Rb \computed \lead \bq`), box styles; `\input`s the sections |
| `sections/00_front.tex` | title page; The problem + Scope, method and conventions; In one page; Contents and routes |
| `sections/01_topic.tex` … `10_reading.tex` | chapters 1–10 (see the chapter table) |
| `sections/A_glossary.tex` | glossary of both fields (30 terms) |
| `refs.bib` | 161 entries, `unsrtnat`; preprints are `@misc` with `howpublished = {Preprint, \arxiv{ID}}`; `\vpartial{…}` marks what could only be partly verified |
| `figures/make_figures.py`, `figures/grid.csv` | matplotlib figures 2.2 (crossover, computed) and 5.1 (coverage matrix); `fig_crossover_data.csv` and `coverage_matrix.csv` list the ledger ids behind every point and tile |
| `tools/build.sh` | pdflatex → bibtex → `splitbbl.py` (moves the Vienna group to the end, numbering continues) → `stats.py` (writes `stats.tex` for the title page and method box) → two more passes |
| `tools/pages.py`, `sheets.sh`, `fill.py`, `citeuse.py`, `guard.py`, `worddiff.sh`, `flat.py` | page spans, contact sheets, front-page fill, citation usage, rewrite guard, word diff, single-file `.tex` |
| `map_flat.tex` | single-file version (project copy) |
| `facts_ledger.md`, `method_notes.md` | the ledger every number traces to (345 lines) and the method log |

| # | chapter | file | pages |
|---|---|---|---|
| 1 | The topic in brief | 01_topic | 1–2 |
| 2 | Foundations | 02_foundations | 3–6 |
| 3 | Context: electronic moiré and quantum geometry for Bose-gas physicists | 03_context | 7–9 |
| 4 | Data, benchmarks and verification | 04_benchmarks | 10–11 |
| 5 | State of the art | 05_state | 12–15 |
| 6 | Position: geometric superfluidity is excluded; the pocket crossover is the open problem | 06_position | 16–18 |
| 7 | Around the topic | 07_around | 19–20 |
| 8 | Research and industry perspective | 08_perspective | 21–23 |
| 9 | Open questions (Q1–Q22, D1–D7) | 09_open | 24–26 |
| 10 | Reading paths and outlook | 10_reading | 27–28 |
| — | References; Research connected with the WPI and Vienna; A Glossary | | 29–39 |

## Build

```
bash tools/build.sh        # from this folder; needs TeX Live (mathpazo, helvet, tcolorbox, tikz, natbib, doi, xurl …), python3, matplotlib
python3 figures/make_figures.py   # only if the figures are to be regenerated (reads figures/grid.csv)
```
Do not run `latexmk` alone: the Vienna group at the end of the references is produced by `tools/splitbbl.py`
after `bibtex`, and the counts on the title page come from `stats.tex` written by `tools/stats.py`.

## How it was made and what the checks found

Sources came from five project documents and the two-page proposal (about 100 sources), extended by three
research agents (134 web calls, 2011–2026; `work/search_log.md`), and every source was opened once in eleven
checking rounds (arXiv/ar5iv, nature.com, code repositories, search listings; journals.aps.org, OpenAlex and
Crossref were blocked): 56 sources verified or corrected, 105 partly verified (mostly APS volume numbers read
from listings only), 0 not verifiable among the cited ones. A rewrite pass with a citation/number guard, a
reader review and an independent final fact-check followed; the final check found and fixed 12 items (e.g. a
misplaced group attribution, a lost uniform-density condition, a Leggett-bound falsifier that was logically
impossible). Corrections to the project documents' bibliographic data and claims are listed in
`corrections_list.md`; the most consequential:

- Huhtinen et al. 2026: the no-go statement reads "There can therefore be no superfluidity in a single flat band at
  a TRIM where the Bloch state has uniform densities." (not the docs' shorter form); "≥ 3 bands" holds "within
  Bogoliubov theory"; the paper does not call its condensate metric the minimal metric.
- orso2024 is a unitary Fermi-gas paper; underwood2025 is spin-1; Pérez-Cruz et al. are not Fattori's group;
  salamon2020 is fermionic; han2025 is non-moiré; "Lukin–Sotnikov–Kruchkov 2023" was not found.
- Kariyado–Vishwanath is paraphrased (the docs' quotation is not in the paper); Paul et al.'s threshold is 0.03 t⊥
  (commensurate) / 0.06 t⊥ (incommensurate) and their term is "mobility islands".
- Numbers deliberately not used: Rabec's f_s = 0.82(2), Braun's 0.3–0.6 exponent range, Chauveau/Tao numeric f_s
  values, a "~10×" TBG stiffness factor for Tanaka 2025 (only zhou2026 quotes it, about tian2023).
- The grid.csv claims "W₁ ≥ 0.93 W₁(0) at 4 E_R" and "weak m-dependence" hold at m = 8 only (0.59 at m = 12); the
  experiment's angle m = 22 was never computed; the PR drop over Ω/J ≈ 10–30 is a factor ≈ 24, not 2–3 decades.

## Rules for a later polishing pass

1. Keep numbers, units, quotations and the reference each statement cites; re-check against `facts_ledger.md`.
2. Keep the hedges: "preprint", "as quoted", "as reported", "according to the company/page", "was (not) found for
   this map", "within Bogoliubov theory", "as the project documents summarise", and every `\computed` tag with
   its "m = 8, V₀ = 8 E_R" qualifier.
3. Keep versions apart: Zeng 2025 (two arXiv titles), Fan 2025 (title change), Xia/Guo print year 2025.
4. Keep the map project-neutral (no solver internals, gates or plans).
5. After editing run `bash tools/build.sh`, check overfull/undefined counts, that all 161 entries are cited
   (`python3 tools/citeuse.py`), and rerun `tools/fill.py` on the front pages.

## Known limitations

- 105 sources are `partly verified`: usually the APS volume/article number was only seen in a search listing, or
  a quotation was confirmed only in part; each carries a `\vpartial` note in the bibliography.
- The Vienna-group entries stimming2010, moller2023, exl2016, bao2003 were checked bibliographically only
  (`work/verify/batch_11_vienna.md`).
- Six coverage-matrix cells are drawn empty because the ledger does not say (see `figures/coverage_matrix.csv`).
- No second twisted-lattice atom experiment, no released TBOL data set and no |1,1⟩/|2,0⟩ ⁸⁷Rb scattering-length
  set were found; the map says so where it matters.
