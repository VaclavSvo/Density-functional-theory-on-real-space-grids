import re, os
t = open("review.toc").read() if os.path.exists("review.toc") else ""
r = re.findall(r"contentsline \{section\}\{(?:\\numberline \{([^}]*)\})?([^}]*)\}\{([^}]*)\}", t)
r = [(n, x, int(p)) for n, x, p in r if p.isdigit()]
nxt = [q for _, _, q in r[1:]] + [r[-1][2] + 1 if r else 0]
for (n, x, p), q in zip(r, nxt): print(f"{n:>3} {x[:55]:55} p{p}-{q-1}")
