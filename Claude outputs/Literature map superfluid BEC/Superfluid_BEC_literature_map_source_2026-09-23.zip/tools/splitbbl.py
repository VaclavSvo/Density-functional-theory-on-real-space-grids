"""Post-process review.bbl: move the Vienna/WPI-connected entries into a second, consecutively numbered
list at the end of the references, and wrap both lists in two-column layout."""
import re, sys
VIENNA = ["stimming2010", "mennemann2021", "moller2023", "bao2003", "gutleb2024", "stimming2024", "exl2016", "exl2014", "schaffer2024", "kovacs2022", "schweigler2017", "kasper2020", "moller2025", "uibk2023quanta"]
NOTE = ("Papers and programmes in this map whose authors or hosts are at the Wolfgang Pauli Institute, the University of "
        "Vienna or TU Wien (Atominstitut). First the work of the Mauser, Stimming, Mazets and Exl groups (stochastic "
        "classical fields and dissipative hydrodynamics of 1-D gases, the extended bosonic Josephson junction, "
        "time-splitting and absorbing-layer numerics, fast non-local kernels, physics-informed networks with hard "
        "constraints), then the Schmiedmayer atom-chip quantum field simulator and the Austrian cluster of excellence "
        "quantA. Numbering continues from the main list.")
src = open("review.bbl", encoding="utf-8").read()
head, body = src.split("\\begin{thebibliography}", 1)
arg, rest = body.split("\n", 1)
items_txt, tail = rest.rsplit("\\end{thebibliography}", 1)
items = re.split(r"(?=\\bibitem)", items_txt)
pre = items[0]; items = items[1:]
def key(it):
    m = re.search(r"\\bibitem(?:\[[^\]]*\])?\{([^}]*)\}", it); return m.group(1) if m else ""
main = [it for it in items if key(it) not in VIENNA]
vie = [it for it in items if key(it) in VIENNA]
vie.sort(key=lambda it: VIENNA.index(key(it)))
n_main = len(main)
out = (head + "\\begin{multicols}{2}{\\footnotesize\\RaggedRight\n\\begin{thebibliography}" + arg + "\n" + pre
       + "".join(main).rstrip() + "\n\\end{thebibliography}}\\end{multicols}\n"
       "\\par\\medskip\\phantomsection\\addcontentsline{toc}{section}{Research connected with the WPI and Vienna}\n"
       "{\\sffamily\\Large\\bfseries\\color{headblue} Research connected with the WPI and Vienna}\\par\\smallskip\n"
       "{\\small\\color{inktwo}\\itshape " + NOTE + "}\\par\\medskip\n"
       "\\begin{multicols}{2}{\\footnotesize\\RaggedRight\n\\begin{thebibliography}" + arg
       + "\\makeatletter\\setcounter{NAT@ctr}{" + str(n_main) + "}\\makeatother\n"
       + "".join(vie).rstrip() + "\n\\end{thebibliography}}\\end{multicols}\n" + tail)
open("review.bbl", "w", encoding="utf-8").write(out)
print(f"splitbbl: {n_main} main entries, {len(vie)} Vienna/WPI entries: {[key(i) for i in vie]}")
