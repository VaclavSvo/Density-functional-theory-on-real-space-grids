import re, glob, os
rd = lambda p: open(p, encoding="utf-8").read() if os.path.exists(p) else ""
secs = "".join(rd(f) for f in sorted(glob.glob("sections/[0-9]*.tex")) if not f.endswith("00_front.tex"))
ref = re.search(r"\{References\}\{(\d+)\}", rd("review.toc"))
KNOWN = ("verified", "corrected", "partly verified", "not verifiable", "retry", "to check", "unchecked")
cited = {k.strip() for m in re.finditer(r"\\citation\{([^}]*)\}", rd("review.aux")) for k in m.group(1).split(",")}
status, uncited = {}, 0
for line in rd("../work/verify/progress.md").splitlines():
    raw = [c.strip() for c in line.split("|")]
    cells = [c.lower().strip("`* ") for c in raw]
    hit = [c for c in cells if c in KNOWN]
    key = next((c.strip("`* ") for c in raw if c.strip("`* ")), "")
    if hit and key in cited: status[key] = hit[0]
    elif hit: uncited += 1
    elif any(k in c for c in cells for k in KNOWN):
        print("WARNING: status cell not exact, row not counted:", line.strip())
missing = sorted(cited - set(status))
if uncited or missing:
    print(f"note: {uncited} checked rows are not cited in this build; cited but not in progress.md: {missing}")
n = lambda *s: sum(v in s for v in status.values()) + (len(missing) if "unchecked" in s else 0)
stats = {"statChapters": len(re.findall(r"\\section\{", secs)),
         "statPages": int(ref.group(1)) - 1 if ref else "--",
         "statSources": rd("review.bbl").count("\\bibitem"),
         "statFigures": len(re.findall(r"\\begin\{figure", secs)),
         "statQuestions": len(re.findall(r"\\bq\{", secs)),
         "statVerified": n("verified", "corrected"),
         "statPartly": n("partly verified"),
         "statUnverifiable": n("not verifiable"),
         "statRetry": n("retry"),
         "statUnchecked": n("to check", "unchecked")}
stats["statChecked"] = stats["statVerified"] + stats["statPartly"] + stats["statUnverifiable"]
open("stats.tex", "w").write("".join(f"\\providecommand{{\\{k}}}{{}}\\renewcommand{{\\{k}}}{{{v}}}\n" for k, v in stats.items()))
print(stats)
